-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 04, 2026 at 09:22 AM
-- Server version: 8.4.3
-- PHP Version: 8.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `anexpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint UNSIGNED NOT NULL,
  `role_id` bigint DEFAULT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `role_id`, `name`, `email`, `username`, `email_verified_at`, `image`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 'Super Admin', 'admin@example.com', 'admin', NULL, '6864d156b3f2e1751437654.jpg', '$2y$12$KCGCuWN/lg5cjhwNg5HI6Oliv1SCFmnU4Jqad9513ldWq/WGyErLO', '8DBdeSsvTf5a0poztWxxARaNxuWmP51lNmEaM6K79Y0oAfNS2fEcNAJNRQ2h', NULL, '2025-09-13 00:30:05'),
(3, 3, 'Manager', 'manager@gmail.com', 'manager', NULL, '686a18d8e2e881751783640.jpg', '$2y$12$x8DlEz5FlUm7NpfXROifY.MoQYrUNntJs8/24lasApzSh1PZ2rIFO', NULL, '2025-07-06 00:34:02', '2025-07-06 00:34:02');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT '0',
  `click_url` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `user_id`, `title`, `read_status`, `click_url`, `created_at`, `updated_at`) VALUES
(1, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-01-21 07:29:16', '2023-01-21 07:29:16'),
(2, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-01-21 07:40:48', '2023-01-21 07:40:48'),
(3, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-01-21 07:43:51', '2023-01-21 07:43:51'),
(4, 32, 'New member registered', 0, '/admin/manage/users/detail/32', '2023-03-22 04:09:55', '2023-03-22 04:09:55'),
(5, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-03-22 04:09:57', '2023-03-22 04:09:57'),
(6, 32, 'Deposit request from testuser1', 0, '/admin/manage/deposits/details/64', '2023-05-27 02:51:35', '2023-05-27 02:51:35'),
(7, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-05-27 02:51:35', '2023-05-27 02:51:35'),
(8, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-12-11 09:19:25', '2023-12-11 09:19:25'),
(9, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-12-11 09:19:45', '2023-12-11 09:19:45'),
(10, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-12-11 09:20:04', '2023-12-11 09:20:04'),
(11, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2023-12-11 09:21:07', '2023-12-11 09:21:07'),
(12, 0, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', 0, '#', '2024-02-03 09:59:12', '2024-02-03 09:59:12'),
(13, 8, 'New support ticket has opened', 0, '/admin/support/tickets/view/53', '2025-07-02 06:21:47', '2025-07-02 06:21:47'),
(14, 0, 'A new support ticket has opened ', 0, '/admin/support/tickets/view/54', '2025-07-02 06:22:21', '2025-07-02 06:22:21'),
(15, 8, 'New support ticket has opened', 0, '/admin/support/tickets/view/55', '2025-07-02 06:42:54', '2025-07-02 06:42:54'),
(16, 0, 'A new support ticket has opened ', 0, '/admin/support/tickets/view/56', '2025-07-02 06:43:13', '2025-07-02 06:43:13'),
(17, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 1, '#', '2025-07-02 07:46:09', '2025-07-07 00:08:46'),
(18, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 1, '#', '2025-07-02 07:46:21', '2025-07-07 00:08:46'),
(19, 8, 'New withdraw request from hinglemay', 0, '/admin/manage/withdrawals/details/5', '2025-07-07 05:55:08', '2025-07-07 05:55:08'),
(20, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-07 05:55:08', '2025-07-07 05:55:08'),
(21, 8, 'Deposit request from hinglemay', 0, '/admin/manage/deposits/details/66', '2025-07-07 05:56:35', '2025-07-07 05:56:35'),
(22, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-07 05:56:35', '2025-07-07 05:56:35'),
(23, 34, 'New member registered', 0, '/admin/manage/users/detail/34', '2025-07-08 00:27:50', '2025-07-08 00:27:50'),
(24, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-08 00:28:24', '2025-07-08 00:28:24'),
(25, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-08 00:32:57', '2025-07-08 00:32:57'),
(26, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-08 00:40:12', '2025-07-08 00:40:12'),
(27, 0, 'SMS Error: Got error response from the server: Request not allowed (incorrect access_key)', 0, '#', '2025-07-08 01:00:59', '2025-07-08 01:00:59'),
(28, 34, 'Deposit request from rajibhossain', 0, '/admin/manage/deposits/details/67', '2025-07-08 01:06:00', '2025-07-08 01:06:00'),
(29, 34, 'Deposit request from rajibhossain', 0, '/admin/manage/deposits/details/68', '2025-07-08 01:10:59', '2025-07-08 01:10:59'),
(30, 34, 'Deposit request from rajibhossain', 0, '/admin/manage/deposits/details/69', '2025-07-08 01:12:09', '2025-07-08 01:12:09'),
(31, 34, 'New withdraw request from rajibhossain', 0, '/admin/manage/withdrawals/details/6', '2025-07-08 01:15:00', '2025-07-08 01:15:00'),
(32, 34, 'New withdraw request from rajibhossain', 0, '/admin/manage/withdrawals/details/7', '2025-07-08 01:16:50', '2025-07-08 01:16:50'),
(33, 0, 'A new pickup request has been submitted', 0, '/admin/pickup-requests/view/1', '2026-09-01 01:14:39', '2026-09-01 01:14:39'),
(34, 0, 'A new pickup request has been submitted', 0, '/admin/pickup-requests/view/2', '2026-09-01 01:28:23', '2026-09-01 01:28:23'),
(35, 0, 'A new quote request has been submitted', 0, '/admin/quote-requests/view/1', '2026-09-01 01:55:22', '2026-09-01 01:55:22'),
(36, 0, 'A new online booking has been submitted', 0, '/admin/bookings/view/1', '2026-09-01 02:15:48', '2026-09-01 02:15:48'),
(37, 0, 'A new quote request has been submitted', 0, '/admin/quote-requests/view/2', '2026-09-02 04:58:33', '2026-09-02 04:58:33'),
(38, 0, 'A new online booking has been submitted', 0, '/admin/bookings/view/2', '2026-09-02 05:00:44', '2026-09-02 05:00:44'),
(39, 0, 'A new pickup request has been submitted', 0, '/admin/pickup-requests/view/3', '2026-09-02 05:01:48', '2026-09-02 05:01:48'),
(40, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/1', '2026-09-18 05:16:27', '2026-09-18 05:16:27'),
(41, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/2', '2026-09-18 10:05:45', '2026-09-18 10:05:45'),
(42, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/3', '2026-09-18 10:06:47', '2026-09-18 10:06:47'),
(43, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/4', '2026-09-22 19:43:50', '2026-09-22 19:43:50'),
(44, 0, 'A new pickup request has been submitted', 0, '/admin/pickup-requests/view/4', '2026-09-26 07:10:51', '2026-09-26 07:10:51'),
(45, 0, 'A new pickup request has been submitted', 0, '/admin/pickup-requests/view/5', '2026-09-27 07:33:04', '2026-09-27 07:33:04'),
(46, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/5', '2026-09-28 22:07:16', '2026-09-28 22:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_resets`
--

CREATE TABLE `admin_password_resets` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_password_resets`
--

INSERT INTO `admin_password_resets` (`id`, `email`, `token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin@example.com', '880076', 0, '2025-07-07 03:21:13', NULL),
(2, 'admin@example.com', '580582', 1, '2025-07-07 03:22:10', NULL),
(3, 'admin@example.com', '191758', 0, '2025-09-13 00:06:04', NULL),
(4, 'admin@example.com', '252380', 1, '2025-09-13 00:25:41', NULL),
(5, 'admin@example.com', '200650', 0, '2025-10-22 06:01:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `booking_requests`
--

CREATE TABLE `booking_requests` (
  `id` bigint UNSIGNED NOT NULL,
  `shipper_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_zip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_zip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consignee_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipment_ref` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pieces` int UNSIGNED NOT NULL DEFAULT '1',
  `declared_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight_kg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight_gm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `length` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `height` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `volumetric_weight` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `method_code` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `method_currency` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `final_amo` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `detail` text COLLATE utf8mb4_general_ci,
  `btc_amo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `btc_wallet` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `trx` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `try` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=>success, 2=>pending, 3=>cancel',
  `from_api` tinyint(1) NOT NULL DEFAULT '0',
  `admin_feedback` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `form_data` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `act`, `form_data`, `created_at`, `updated_at`) VALUES
(2, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number_22\":{\"name\":\"NID Number 22\",\"label\":\"nid_number_22\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"textarea\"},\"sadfg\":{\"name\":\"sadfg\",\"label\":\"sadfg\",\"is_required\":\"optional\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"asdf\":{\"name\":\"asdf\",\"label\":\"asdf\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"Test2\",\"Test3\"],\"type\":\"select\"},\"nid_number_226985\":{\"name\":\"NID Number 226985\",\"label\":\"nid_number_226985\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"Test 2\",\"Test 3\"],\"type\":\"checkbox\"},\"nid_number_3333\":{\"name\":\"NID Number 3333\",\"label\":\"nid_number_3333\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"asdf\"],\"type\":\"radio\"},\"nid_number_3333587\":{\"name\":\"NID Number 3333587\",\"label\":\"nid_number_3333587\",\"is_required\":\"optional\",\"extensions\":\"jpg,bmp,png,pdf\",\"options\":[],\"type\":\"file\"}}', '2022-03-16 01:09:49', '2022-03-17 00:02:54'),
(3, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number_226985\":{\"name\":\"NID Number 226985\",\"label\":\"nid_number_226985\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-16 04:32:29', '2022-03-16 04:35:32'),
(5, 'withdraw_method', '{\"nid_number_33\":{\"name\":\"NID Number 33\",\"label\":\"nid_number_33\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-17 00:45:35', '2022-03-17 00:53:17'),
(6, 'withdraw_method', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-17 00:47:04', '2022-03-17 00:47:04'),
(7, 'kyc', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"gender\":{\"name\":\"Gender\",\"label\":\"gender\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Male\",\"Female\",\"Others\"],\"type\":\"select\"},\"you_hobby\":{\"name\":\"You Hobby\",\"label\":\"you_hobby\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Programming\",\"Gardening\",\"Traveling\",\"Others\"],\"type\":\"checkbox\"},\"nid_photo\":{\"name\":\"NID Photo\",\"label\":\"nid_photo\",\"is_required\":\"required\",\"extensions\":\"jpg,png\",\"options\":[],\"type\":\"file\"}}', '2022-03-17 02:56:14', '2025-08-13 02:16:48'),
(8, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-03-21 07:53:25', '2022-03-21 07:53:25'),
(9, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-03-21 07:54:15', '2022-03-21 07:54:15'),
(10, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-21 07:55:15', '2022-03-21 07:55:22'),
(11, 'withdraw_method', '{\"nid_number_2658\":{\"name\":\"NID Number 2658\",\"label\":\"nid_number_2658\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[\"asdf\"],\"type\":\"checkbox\"}}', '2022-03-22 00:14:09', '2022-03-22 00:14:18'),
(12, 'withdraw_method', '[]', '2022-03-30 09:03:12', '2022-03-30 09:03:12'),
(13, 'withdraw_method', '{\"recipient_full_name\":{\"name\":\"Recipient Full Name\",\"label\":\"recipient_full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_confirmation\":{\"name\":\"Email for Confirmation\",\"label\":\"email_for_confirmation\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2022-03-30 09:09:11', '2025-09-21 07:25:23'),
(14, 'withdraw_method', '{\"mobile_banking_provider\":{\"name\":\"Mobile Banking Provider\",\"label\":\"mobile_banking_provider\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_name\":{\"name\":\"Account Name\",\"label\":\"account_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"mobile_banking_number\":{\"name\":\"Mobile Banking Number\",\"label\":\"mobile_banking_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2022-03-30 09:10:12', '2025-09-21 07:25:04'),
(15, 'manual_deposit', '{\"send_from_number\":{\"name\":\"Send From Number\",\"label\":\"send_from_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transaction_number\":{\"name\":\"Transaction Number\",\"label\":\"transaction_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"screenshot\":{\"name\":\"Screenshot\",\"label\":\"screenshot\",\"is_required\":\"required\",\"extensions\":\"jpg,jpeg,png\",\"options\":[],\"type\":\"file\"}}', '2022-03-30 09:15:27', '2022-03-30 09:15:27'),
(16, 'manual_deposit', '{\"transaction_number\":{\"name\":\"Transaction Number\",\"label\":\"transaction_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"screenshot\":{\"name\":\"Screenshot\",\"label\":\"screenshot\",\"is_required\":\"required\",\"extensions\":\"jpg,pdf,docx\",\"options\":[],\"type\":\"file\"}}', '2022-03-30 09:16:43', '2022-04-11 03:19:54'),
(17, 'manual_deposit', '[]', '2022-03-30 09:21:19', '2022-03-30 09:21:19'),
(18, 'manual_deposit', '{\"asdfasddf\":{\"name\":\"asdfasddf\",\"label\":\"asdfasddf\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-09-28 04:50:55', '2022-09-28 04:50:55'),
(19, 'manual_deposit', '{\"sadf\":{\"name\":\"sadf\",\"label\":\"sadf\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"textarea\"}}', '2022-09-28 05:13:04', '2022-09-28 05:13:59'),
(20, 'manual_deposit', '{\"transaction_id\":{\"name\":\"Transaction ID\",\"label\":\"transaction_id\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2023-05-27 02:50:43', '2023-05-27 02:50:43'),
(21, 'manual_deposit', '{\"depositor_full_name\":{\"name\":\"Depositor Full Name\",\"label\":\"depositor_full_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transfer_reference_code\":{\"name\":\"Transfer Reference Code\",\"label\":\"transfer_reference_code\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"deposit_amount\":{\"name\":\"Deposit Amount\",\"label\":\"deposit_amount\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(22, 'manual_deposit', '{\"sender_name\":{\"name\":\"Sender Name\",\"label\":\"sender_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"mobile_money_number\":{\"name\":\"Mobile Money Number\",\"label\":\"mobile_money_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transaction_reference_id\":{\"name\":\"Transaction Reference ID\",\"label\":\"transaction_reference_id\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"amount_sent\":{\"name\":\"Amount Sent\",\"label\":\"amount_sent\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"email_for_notification\":{\"name\":\"Email for Notification\",\"label\":\"email_for_notification\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-06-29 03:30:31', '2025-09-21 07:21:49'),
(23, 'manual_deposit', '{\"payer_full_name\":{\"name\":\"Payer Full Name\",\"label\":\"payer_full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"transaction_id\":{\"name\":\"Transaction ID\",\"label\":\"transaction_id\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"cash_amount\":{\"name\":\"Cash Amount\",\"label\":\"cash_amount\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"branch_name\":{\"name\":\"Branch Name\",\"label\":\"branch_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_notification\":{\"name\":\"Email for Notification\",\"label\":\"email_for_notification\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(24, 'withdraw_method', '{\"account_holder_name\":{\"name\":\"Account Holder Name\",\"label\":\"account_holder_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"branch_code\":{\"name\":\"Branch Code\",\"label\":\"branch_code\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"optional\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_confirmation\":{\"name\":\"Email for Confirmation\",\"label\":\"email_for_confirmation\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-06-29 04:40:12', '2025-09-21 07:24:39'),
(25, 'manual_deposit', '{\"sender_name\":{\"name\":\"Sender Name\",\"label\":\"sender_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"transfer_reference_number\":{\"name\":\"Transfer Reference Number\",\"label\":\"transfer_reference_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"amount_sent\":{\"name\":\"Amount Sent\",\"label\":\"amount_sent\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_confirmation\":{\"name\":\"Email for Confirmation\",\"label\":\"email_for_confirmation\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-08-13 02:19:06', '2025-09-21 07:23:50'),
(26, 'withdraw_method', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-10-02 03:39:46', '2025-10-02 03:51:05'),
(27, 'withdraw_method', '{\"education\":{\"name\":\"Education\",\"label\":\"education\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-10-02 03:51:41', '2025-10-02 03:51:41'),
(28, 'manual_deposit', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-10-02 04:00:36', '2025-10-02 04:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `frontends`
--

CREATE TABLE `frontends` (
  `id` bigint UNSIGNED NOT NULL,
  `data_keys` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_values` longtext COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `frontends`
--

INSERT INTO `frontends` (`id`, `data_keys`, `data_values`, `created_at`, `updated_at`) VALUES
(1, 'seo.data', '{\"seo_image\":\"1\",\"keywords\":[\"website\",\"services\",\"test\"],\"description\":\"AN Express BD offers fast, safe, and reliable courier delivery services across Bangladesh. Book your parcel, track in real-time, and enjoy doorstep pickup.\",\"social_title\":\"AN Express BD | Fast &amp; Reliable Courier &amp; Parcel Delivery\",\"social_description\":\"Need fast parcel delivery? AN Express BD provides reliable, timely, and secure courier solutions across Bangladesh with seamless tracking.\",\"image\":\"6aaaa28cd7b291789567628.png\"}', '2020-07-04 23:42:52', '2026-09-16 14:10:13'),
(24, 'about.content', '{\"tag\":\"About Us\",\"heading\":\"Delivering Excellence Since 2011\",\"description\":\"An Express Courier started with a simple mission \\u2014 make parcel delivery fast, transparent and stress-free. Today we run a nationwide network of riders, warehouses and delivery hubs, moving thousands of parcels every single day with the same care as our very first shipment.\",\"button_text\":\"Learn More About Us\",\"button_link\":\"\\/about\",\"badge_icon\":\"<i class=\\\"fa-solid fa-box-open\\\"><\\/i>\",\"badge_count\":\"120K+\",\"badge_text\":\"Parcels Delivered\",\"about_image\":\"about.png\"}', '2020-10-28 00:51:20', '2026-08-29 01:05:06'),
(25, 'blog.content', '{\"tag\":\"Our Blog\",\"heading\":\"Latest News & Updates\",\"sub_heading\":\"Tips, industry news and stories from the An Express delivery network.\",\"button_text\":\"View All Articles\",\"button_link\":\"\\/blog\"}', '2020-10-28 00:51:34', '2026-08-29 01:05:06'),
(27, 'contact_us.content', '{\"top_heading\":\"Get In Touch\",\"heading\":\"Let\'s Start a Conversation\",\"short_description\":\"Have a question about a shipment, pricing or partnership? Reach out \\u2014 our team typically replies within a few hours.\",\"button_text\":\"Send Message\",\"short_details\":\"Auctor gravida vestibulu\",\"email_address\":\"uzzalkhan.anexpress@gmail.com\",\"contact_details\":\"123 Gulshan Avenue, Dhaka 1212, Bangladesh\",\"contact_number\":\"+880 1688-042622\",\"support_number\":\"+880 1688-042622\",\"latitude\":\"876768\",\"longitude\":\"67867868\",\"website_footer\":\"<p>Copyright 2022. All rights reserved.<\\/p>\",\"second_email\":\"uzzalkhan.anexpress@gmail.com\",\"working_hours\":\"24\\/7, 365 Days a Year\",\"form_heading\":\"Send Us a Message\",\"form_sub_heading\":\"Fill out the form and we\'ll get back to you shortly.\",\"map_query\":\"Gulshan Avenue, Dhaka, Bangladesh\",\"map_badge\":\"AN Express \\u2014 Head Office\"}', '2020-10-28 00:59:19', '2026-09-26 07:51:56'),
(31, 'social_icon.element', '{\"title\":\"Facebook\",\"social_icon\":\"<i class=\\\"fa-brands fa-facebook-f\\\"><\\/i>\",\"url\":\"#\"}', '2020-11-12 04:07:30', '2026-08-30 03:44:33'),
(36, 'service.content', '{\"tag\":\"Our Services\",\"heading\":\"What We Deliver For You\",\"sub_heading\":\"From same-day local drop-offs to international freight, we\'ve got every delivery need covered.\"}', '2021-03-06 01:27:34', '2026-08-29 01:05:06'),
(39, 'banner.content', '{\"heading\": \"Fast & Secure\", \"cta_text\": \"Ready to ship with us?\", \"badge_icon\": \"<i class=\\\"fa-solid fa-bolt\\\"></i>\", \"badge_text\": \"#1 Trusted Courier Service\", \"sub_heading\": \"Send parcels, documents and packages across the city, country or the globe with real-time tracking and guaranteed on-time delivery.\", \"banner_image\": \"banner.png\", \"heading_after\": \"At Your Doorstep\", \"highlight_text\": \"Delivery\", \"button_one_link\": \"/pickup\", \"button_one_text\": \"Pickup\", \"button_two_link\": \"#how\", \"button_two_text\": \"How It Works\", \"cta_button_one_link\": \"/quote\", \"cta_button_one_text\": \"Get a Free Quote\", \"cta_button_two_link\": \"/pickup\", \"cta_button_two_text\": \"Schedule Pickup\"}', '2021-05-02 06:09:30', '2026-08-29 01:05:06'),
(41, 'cookie.data', '{\"short_desc\":\"We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking \\\"Accept\\\", you consent to our use of cookies.\",\"description\":\"<h4>GDPR, cookies and compliance&nbsp;<\\/h4><ul><li>The&nbsp;General Data Protection Regulation (GDPR)&nbsp;is an EU legislation that governs all collection and processing of personal data from individuals inside the EU.<\\/li><li>Under the EU\\u2019s GDPR, it is the&nbsp;legal responsibility of website owners and operators&nbsp;to make sure that personal data is collected and processed lawfully.<\\/li><li>A website outside of the EU is required to comply with the GDPR if it collects&nbsp;data from users inside the EU.<\\/li><\\/ul><p>&nbsp;<\\/p><p>Even though cookies are mentioned only once in the GDPR,&nbsp;cookie consent&nbsp;is nonetheless a cornerstone of compliance for websites with EU-located users.<\\/p><p>This is because&nbsp;one of the most common ways for personal data to be collected and shared online is through website cookies. The GDPR sets out specific rules for the use of cookies.<\\/p><p>That\\u2019s why end-user consent to cookies is the GDPR\\u2019s most used legal basis that allows websites to process personal data and use cookies.&nbsp;<\\/p>\",\"status\":1}', '2020-07-04 23:42:52', '2025-06-28 01:20:26'),
(42, 'policy_pages.element', '{\"title\":\"Privacy Policy\",\"details\":\"<h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><p>natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.<\\/p><p>\\u00a0<\\/p><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p><p>\\u00a0<\\/p><h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p><p>\\u00a0<\\/p><h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><p>natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.\\u00a0<\\/p><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p>\"}', '2021-06-09 08:50:42', '2022-12-17 06:01:31'),
(43, 'policy_pages.element', '{\"title\":\"Terms of Service\",\"details\":\"<h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><p>natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.<\\/p><p>\\u00a0<\\/p><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p><p>\\u00a0<\\/p><h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><ul><li>Consequuntur quia consequuntur\\u00a0<\\/li><li>Eos qui ratione voluptatem\\u00a0<\\/li><li>Dolores eos qui ratione voluptatem<\\/li><li>Quis autem vel eum iure\\u00a0<\\/li><\\/ul><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p><p>\\u00a0<\\/p><h3><strong>Sed ut perspiciatis unde omnis iste\\u00a0<\\/strong><\\/h3><p>natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.\\u00a0<\\/p><p>\\u00a0<\\/p><h3><strong>Nisi ut aliquid ex ea commodi consequatur<\\/strong><\\/h3><p>qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?<\\/p>\"}', '2021-06-09 08:51:18', '2022-12-17 06:01:43'),
(44, 'maintenance.data', '{\"description\":\"<h4>We\'ll Be Back Soon!<\\/h4><p>&nbsp;<\\/p><p>Thank you for visiting our website. We are currently performing scheduled maintenance to improve your experience.&nbsp;We appreciate your patience and understanding. If you need immediate assistance, please contact us at info@arsignal.com.&nbsp;Thank you for your support!<\\/p>\"}', '2020-07-04 23:42:52', '2025-06-28 02:39:26'),
(66, 'social_icon.element', '{\"title\":\"Instagram\",\"social_icon\":\"<i class=\\\"fa-brands fa-instagram\\\"><\\/i>\",\"url\":\"#\"}', '2025-09-24 03:53:31', '2026-08-30 03:44:33'),
(68, 'header.content', '{\"address\":\"Dhaka, Bangladesh\",\"booking_button_text\":\"Online Booking\",\"booking_button_link\":\"book\"}', '2026-08-29 01:05:06', '2026-09-29 06:48:04'),
(69, 'banner.element', '{\"counter_value\":\"15\",\"title\":\"Years Experience\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(70, 'banner.element', '{\"counter_value\":\"500\",\"title\":\"Cities Covered\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(71, 'banner.element', '{\"counter_value\":\"98\",\"title\":\"% On-Time Rate\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(72, 'brand_strip.element', '{\"icon\":\"<i class=\\\"fa-solid fa-shield-halved\\\"><\\/i>\",\"title\":\"Insured Shipping\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(73, 'brand_strip.element', '{\"icon\":\"<i class=\\\"fa-solid fa-clock\\\"><\\/i>\",\"title\":\"24\\/7 Support\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(74, 'brand_strip.element', '{\"icon\":\"<i class=\\\"fa-solid fa-money-bill-wave\\\"><\\/i>\",\"title\":\"Cash on Delivery\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(75, 'brand_strip.element', '{\"icon\":\"<i class=\\\"fa-solid fa-globe\\\"><\\/i>\",\"title\":\"50+ Countries\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(76, 'brand_strip.element', '{\"icon\":\"<i class=\\\"fa-solid fa-star\\\"><\\/i>\",\"title\":\"4.9\\/5 Rated\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(77, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-city\\\"><\\/i>\",\"title\":\"Domestic Delivery\",\"description\":\"Reliable door-to-door parcel delivery to every district, on schedule, every time.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(78, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-earth-asia\\\"><\\/i>\",\"title\":\"International Shipping\",\"description\":\"Ship worldwide with full customs support and door-step international delivery.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(79, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-bolt\\\"><\\/i>\",\"title\":\"Same Day Delivery\",\"description\":\"Urgent parcel? We pick up and deliver within the same day across the city.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(80, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-warehouse\\\"><\\/i>\",\"title\":\"Warehousing\",\"description\":\"Secure, climate-controlled storage solutions with easy inventory management.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(81, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-money-bill-transfer\\\"><\\/i>\",\"title\":\"Cash on Delivery\",\"description\":\"Collect payment on delivery with secure, next-day settlement to your account.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(82, 'service.element', '{\"icon\":\"<i class=\\\"fa-solid fa-boxes-packing\\\"><\\/i>\",\"title\":\"Bulk & Freight\",\"description\":\"Cost-effective bulk shipping and freight solutions for growing businesses.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(83, 'about.element', '{\"title\":\"Licensed & fully insured shipments\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(84, 'about.element', '{\"title\":\"Eco-friendly, GPS-tracked fleet\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(85, 'about.element', '{\"title\":\"Nationwide & international network\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(86, 'about.element', '{\"title\":\"Dedicated 24\\/7 customer support\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(87, 'how_it_works.content', '{\"tag\":\"Process\",\"heading\":\"How It Works\",\"sub_heading\":\"Sending a parcel with An Express takes just four simple steps.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(88, 'how_it_works.element', '{\"serial\":\"01\",\"icon\":\"<i class=\\\"fa-solid fa-calendar-check\\\"><\\/i>\",\"title\":\"Book a Pickup\",\"description\":\"Schedule a pickup online or via our mobile app in under a minute.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(89, 'how_it_works.element', '{\"serial\":\"02\",\"icon\":\"<i class=\\\"fa-solid fa-truck-ramp-box\\\"><\\/i>\",\"title\":\"We Collect\",\"description\":\"Our rider arrives at your doorstep to securely collect your parcel.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(90, 'how_it_works.element', '{\"serial\":\"03\",\"icon\":\"<i class=\\\"fa-solid fa-route\\\"><\\/i>\",\"title\":\"In Transit\",\"description\":\"Track your parcel live as it moves through our delivery network.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(91, 'how_it_works.element', '{\"serial\":\"04\",\"icon\":\"<i class=\\\"fa-solid fa-house-circle-check\\\"><\\/i>\",\"title\":\"Delivered\",\"description\":\"Your parcel arrives safely, on time, with instant delivery confirmation.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(92, 'why_choose_us.content', '{\"tag\":\"Why Choose Us\",\"heading\":\"Delivering Trust, One Parcel at a Time\",\"badge_icon\":\"<i class=\\\"fa-solid fa-truck-fast\\\"><\\/i>\",\"badge_count\":\"15+\",\"badge_text\":\"Years of Trusted Service\",\"why_image\":\"why.png\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(93, 'why_choose_us.element', '{\"icon\":\"<i class=\\\"fa-solid fa-shield-halved\\\"><\\/i>\",\"title\":\"100% Secure & Insured\",\"description\":\"Every parcel is insured and handled with strict security protocols.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(94, 'why_choose_us.element', '{\"icon\":\"<i class=\\\"fa-solid fa-location-crosshairs\\\"><\\/i>\",\"title\":\"Real-Time GPS Tracking\",\"description\":\"Track your shipment live from pickup to final delivery.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(95, 'why_choose_us.element', '{\"icon\":\"<i class=\\\"fa-solid fa-headset\\\"><\\/i>\",\"title\":\"24\\/7 Customer Support\",\"description\":\"Our support team is available round the clock to assist you.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(96, 'why_choose_us.element', '{\"icon\":\"<i class=\\\"fa-solid fa-tags\\\"><\\/i>\",\"title\":\"Affordable Pricing\",\"description\":\"Transparent, competitive rates with no hidden charges.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(97, 'counter.element', '{\"icon\":\"<i class=\\\"fa-solid fa-box-open\\\"><\\/i>\",\"counter_value\":\"120000\",\"title\":\"Parcels Delivered\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(98, 'counter.element', '{\"icon\":\"<i class=\\\"fa-solid fa-users\\\"><\\/i>\",\"counter_value\":\"25000\",\"title\":\"Happy Clients\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(99, 'counter.element', '{\"icon\":\"<i class=\\\"fa-solid fa-motorcycle\\\"><\\/i>\",\"counter_value\":\"850\",\"title\":\"Delivery Riders\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(100, 'counter.element', '{\"icon\":\"<i class=\\\"fa-solid fa-city\\\"><\\/i>\",\"counter_value\":\"500\",\"title\":\"Cities Covered\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(101, 'testimonial.content', '{\"tag\":\"Testimonials\",\"heading\":\"What Our Customers Say\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(102, 'testimonial.element', '{\"image\":null,\"name\":\"Ayesha Rahman\",\"designation\":\"Online Store Owner\",\"review\":\"\\\"An Express has completely changed how I ship products to my customers. Fast, reliable, and the tracking is spot on!\\\"\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(103, 'testimonial.element', '{\"image\":null,\"name\":\"Tanvir Ahmed\",\"designation\":\"Business Owner\",\"review\":\"\\\"Booked a same-day pickup and my document reached the other city within hours. Excellent service!\\\"\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(104, 'testimonial.element', '{\"image\":null,\"name\":\"Nusrat Jahan\",\"designation\":\"Freelancer\",\"review\":\"\\\"Affordable rates and their support team resolved my query within minutes. Highly recommended courier!\\\"\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(105, 'faq.content', '{\"tag\":\"FAQ\",\"heading\":\"Frequently Asked Questions\",\"sub_heading\":\"Quick answers to the questions we get asked the most.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(106, 'faq.element', '{\"question\":\"How long does delivery usually take?\",\"answer\":\"<p>Domestic deliveries typically arrive within 24\\u201348 hours, while international shipments take 3\\u20137 business days depending on the destination and service level you choose.<\\/p>\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(107, 'faq.element', '{\"question\":\"How can I track my parcel?\",\"answer\":\"<p>Enter your tracking number in the \\\"Track Order\\\" box on this page \\u2014 you\'ll see live, real-time GPS updates from pickup to final delivery.<\\/p>\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(108, 'faq.element', '{\"question\":\"Do you offer cash on delivery?\",\"answer\":\"<p>Yes, cash on delivery is available nationwide with secure, next-day settlement directly to your account.<\\/p>\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(109, 'faq.element', '{\"question\":\"Is my parcel insured during transit?\",\"answer\":\"<p>Every parcel we handle is fully insured and covered by strict security protocols, so you\'re protected from pickup to delivery.<\\/p>\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(110, 'faq.element', '{\"question\":\"How do I get a shipping quote?\",\"answer\":\"<p>Use the Get A Quote form with your parcel and destination details \\u2014 our team replies within 2 business hours.<\\/p>\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(111, 'cta.content', '{\"heading\":\"Ready to Ship Your Parcel?\",\"sub_heading\":\"Join thousands of happy customers who trust An Express for fast and secure delivery.\",\"button_icon\":\"<i class=\\\"fa-solid fa-paper-plane\\\"><\\/i>\",\"button_text\":\"Get Started Now\",\"button_link\":\"\\/pickup\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(112, 'footer.content', '{\"description\":\"Your trusted partner for fast, secure and affordable courier and parcel delivery \\u2014 locally and worldwide.\",\"newsletter_heading\":\"Newsletter\",\"newsletter_text\":\"Subscribe to get updates on offers and new services.\",\"copyright\":\"\\u00a9 2026 An Express Courier. All Rights Reserved.\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(113, 'footer_link_one.content', '{\"heading\":\"Company\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(114, 'footer_link_one.element', '{\"title\":\"Home\",\"link\":\"\\/\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(115, 'footer_link_one.element', '{\"title\":\"Services\",\"link\":\"\\/#services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(116, 'footer_link_one.element', '{\"title\":\"About\",\"link\":\"\\/about\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(117, 'footer_link_one.element', '{\"title\":\"Why Us\",\"link\":\"\\/#why\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(118, 'footer_link_one.element', '{\"title\":\"Reviews\",\"link\":\"\\/#testimonials\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(119, 'footer_link_one.element', '{\"title\":\"Blog\",\"link\":\"\\/blog\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(120, 'footer_link_one.element', '{\"title\":\"Contact\",\"link\":\"\\/contact\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(121, 'footer_link_two.content', '{\"heading\":\"Services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(122, 'footer_link_two.element', '{\"title\":\"Domestic Delivery\",\"link\":\"\\/#services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(123, 'footer_link_two.element', '{\"title\":\"International Shipping\",\"link\":\"\\/#services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(124, 'footer_link_two.element', '{\"title\":\"Same Day Delivery\",\"link\":\"\\/#services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(125, 'footer_link_two.element', '{\"title\":\"Warehousing\",\"link\":\"\\/#services\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(126, 'footer_link_two.element', '{\"title\":\"Online Booking\",\"link\":\"\\/book\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(127, 'footer_link_two.element', '{\"title\":\"Pick-Up Request\",\"link\":\"\\/pickup\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(128, 'footer_link_two.element', '{\"title\":\"Get A Quote\",\"link\":\"\\/quote\"}', '2026-08-29 01:05:06', '2026-08-29 01:05:06'),
(132, 'blog.element', '{\"blog_image\":\"blog-live-tracking.png\",\"category\":\"Industry\",\"title\":\"How Real-Time Tracking Is Changing E-Commerce\",\"quote\":\"Every tracking update is one support ticket that never gets opened.\",\"description\":\"<p>See how live GPS tracking builds customer trust and reduces support queries for online sellers.<\\/p><p>When a buyer can watch their parcel move, the anxious \\\"where is my order\\\" message never gets sent. Sellers report noticeably fewer support tickets within weeks of switching to a tracked service.<\\/p><p>Tracking data also tells you which routes run late, so you can set realistic delivery promises instead of optimistic ones.<\\/p>\"}', '2026-06-10 04:00:00', '2026-06-10 04:00:00'),
(133, 'blog.element', '{\"blog_image\":\"blog-new-cities.png\",\"category\":\"Company News\",\"title\":\"AN Express Expands to 50 New Cities This Year\",\"quote\":\"Faster delivery is not about speed alone, it is about being closer to the customer.\",\"description\":\"<p>We\'re growing our delivery network to bring faster, more reliable service to even more customers.<\\/p><p>Fifty new cities means fifty new local hubs, hundreds of new riders and same-day coverage for regions that previously waited two or three days for a parcel.<\\/p><p>The rollout continues through the year, and every new hub goes live with full GPS tracking and cash-on-delivery support from day one.<\\/p>\"}', '2026-06-28 04:00:00', '2026-08-31 23:54:29'),
(134, 'blog.element', '{\"blog_image\":\"blog-pack-parcel.png\",\"category\":\"Guides\",\"title\":\"5 Tips to Pack Your Parcel for Safe Delivery\",\"quote\":\"A well-packed parcel is the cheapest insurance you can buy.\",\"description\":\"<p>Avoid damaged shipments with these simple packing best practices used by our own warehouse team.<\\/p><p>Choose a box one size larger than your item so there is room for cushioning on every side. Wrap fragile items individually, fill the gaps with air pillows or crumpled paper, and seal every seam of the box with strong tape in an H pattern.<\\/p><p>Finally, remove or cover any old labels and make sure the new address label is flat, fully readable and placed on the largest surface of the parcel.<\\/p>\"}', '2026-07-12 04:00:00', '2026-07-12 04:00:00'),
(135, 'our_story.content', '{\"tag\":\"Our Story\",\"heading\":\"Delivering Excellence Since 2011\",\"description\":\"AN Express started with a simple mission \\u2014 make parcel delivery fast, transparent and stress-free. What began as a two-rider operation in Dhaka has grown into a nationwide network of riders, warehouses and delivery hubs, moving thousands of parcels every single day with the same care as our very first shipment.\",\"description_two\":\"Today, we serve individuals, e-commerce sellers and enterprise clients across the country and worldwide \\u2014 backed by real-time tracking, insured handling and a support team that never sleeps.\",\"button_text\":\"Get A Quote\",\"button_link\":\"\\/quote\",\"badge_icon\":\"<i class=\\\"fa-solid fa-box-open\\\"><\\/i>\",\"badge_count\":\"120K+\",\"badge_text\":\"Parcels Delivered\",\"story_image\":\"our-story.png\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(136, 'our_story.element', '{\"title\":\"Licensed & fully insured shipments\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(137, 'our_story.element', '{\"title\":\"Eco-friendly, GPS-tracked fleet\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(138, 'our_story.element', '{\"title\":\"Nationwide & international network\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(139, 'our_story.element', '{\"title\":\"Dedicated 24\\/7 customer support\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(140, 'mission_vision.element', '{\"icon\":\"<i class=\\\"fa-solid fa-bullseye\\\"><\\/i>\",\"title\":\"Our Mission\",\"description\":\"To connect businesses and people through fast, reliable and affordable delivery \\u2014 making every shipment feel like it\'s our only one.\"}', '2026-08-31 23:01:20', '2026-08-31 23:54:29'),
(141, 'mission_vision.element', '{\"icon\":\"<i class=\\\"fa-solid fa-eye\\\"><\\/i>\",\"title\":\"Our Vision\",\"description\":\"To become the most trusted courier network in the region, known for speed, transparency and care in every single delivery.\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(142, 'team.content', '{\"tag\":\"Our Team\",\"heading\":\"The People Behind Every Delivery\",\"sub_heading\":\"A dedicated team working around the clock to keep your parcels moving safely and on time.\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(143, 'team.element', '{\"image\":\"mahmud-hasan.png\",\"name\":\"Mahmud Hasan\",\"designation\":\"Founder & CEO\",\"facebook_url\":\"#\",\"twitter_url\":\"#\",\"linkedin_url\":\"#\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(144, 'team.element', '{\"image\":\"nusrat-jahan.png\",\"name\":\"Nusrat Jahan\",\"designation\":\"Head of Operations\",\"facebook_url\":\"#\",\"twitter_url\":\"#\",\"linkedin_url\":\"#\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(145, 'team.element', '{\"image\":\"rafiq-islam.png\",\"name\":\"Rafiq Islam\",\"designation\":\"Logistics Manager\",\"facebook_url\":\"#\",\"twitter_url\":\"#\",\"linkedin_url\":\"#\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(146, 'team.element', '{\"image\":\"ayesha-rahman.png\",\"name\":\"Ayesha Rahman\",\"designation\":\"Customer Support Lead\",\"facebook_url\":\"#\",\"twitter_url\":\"#\",\"linkedin_url\":\"#\"}', '2026-08-31 23:01:20', '2026-08-31 23:01:20'),
(147, 'blog_sidebar.content', '{\"cta_icon\":\"<i class=\\\"fa-solid fa-file-invoice\\\"><\\/i>\",\"cta_heading\":\"Need a Shipping Quote?\",\"cta_text\":\"Get a fast, no-obligation rate for your next parcel or bulk shipment.\",\"cta_button_text\":\"Get A Quote\",\"cta_button_link\":\"\\/quote\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(148, 'contact_info.element', '{\"icon\":\"<i class=\\\"fa-solid fa-location-dot\\\"><\\/i>\",\"title\":\"Our Office\",\"details\":\"123 Gulshan Avenue, Dhaka 1212, Bangladesh\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(149, 'contact_info.element', '{\"icon\":\"<i class=\\\"fa-solid fa-phone\\\"><\\/i>\",\"title\":\"Call Us\",\"details\":\"+880 1688-042622\"}', '2026-08-31 23:51:38', '2026-09-26 07:15:43'),
(150, 'contact_info.element', '{\"icon\":\"<i class=\\\"fa-solid fa-envelope\\\"><\\/i>\",\"title\":\"Email Us\",\"details\":\"support@anexpress.com, info@anexpress.com\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(151, 'contact_faq.content', '{\"tag\":\"FAQ\",\"heading\":\"Quick Answers\",\"sub_heading\":\"Common questions before you reach out \\u2014 can\'t find what you need? Just send us a message above.\"}', '2026-08-31 23:51:38', '2026-08-31 23:54:29'),
(152, 'contact_faq.element', '{\"question\":\"How fast can I get a shipping quote?\",\"answer\":\"<p>Most quote requests submitted through our Get A Quote form are answered within 2 business hours. Bulk and freight quotes may take a little longer as we check current carrier rates.<\\/p>\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(153, 'contact_faq.element', '{\"question\":\"Do you offer free pickup?\",\"answer\":\"<p>Yes. Pickup is free for all scheduled shipments inside our city coverage area. For remote locations a small collection fee may apply, and it is always shown before you confirm.<\\/p>\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(154, 'contact_faq.element', '{\"question\":\"What are your support hours?\",\"answer\":\"<p>Our support team is available 24 hours a day, 365 days a year \\u2014 by phone, email and live chat.<\\/p>\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(155, 'contact_faq.element', '{\"question\":\"Can I visit your office directly?\",\"answer\":\"<p>Absolutely. Walk into our Gulshan head office any day of the week and our counter team will help you book, track or collect a parcel.<\\/p>\"}', '2026-08-31 23:51:38', '2026-08-31 23:51:38'),
(156, 'blog.element', '{\"blog_image\":\"blog-air-sea-freight.png\",\"category\":\"Industry\",\"title\":\"Choosing Between Air and Sea Freight for Bulk Orders\",\"quote\":\"Speed costs money. The trick is knowing which shipments are worth paying for.\",\"description\":\"<p>Weigh cost, speed and volume to pick the right freight option for your next big shipment.<\\/p><p>Air freight wins on speed and on high-value, low-weight cargo. Sea freight wins on volume: once a shipment fills a significant part of a container, the per-kilo cost drops far below anything air can offer.<\\/p><p>As a rule of thumb, if the goods are perishable, seasonal or urgently needed, fly them. If they are bulky, durable and planned weeks ahead, ship them.<\\/p>\"}', '2026-04-18 04:00:00', '2026-04-18 04:00:00'),
(157, 'blog.element', '{\"blog_image\":\"blog-sorting-hub.png\",\"category\":\"Company News\",\"title\":\"Behind the Scenes: A Day in Our Sorting Hub\",\"quote\":\"Every parcel passes through six pairs of hands before it reaches your door.\",\"description\":\"<p>From scan to sort to dispatch \\u2014 a look at how thousands of parcels move through our hub daily.<\\/p><p>The day starts at 4am when the first line-haul trucks back into the dock. Parcels are scanned on arrival, weighed, and routed onto belts by destination zone.<\\/p><p>By 9am the outbound vans are loaded and on the road, and the hub resets for the afternoon intake from our pickup riders.<\\/p>\"}', '2026-05-05 04:00:00', '2026-05-05 04:00:00'),
(158, 'blog.element', '{\"blog_image\":\"blog-cash-on-delivery.png\",\"category\":\"Guides\",\"title\":\"Cash on Delivery: What Online Sellers Need to Know\",\"quote\":\"COD converts hesitant buyers, but only if your settlement cycle is predictable.\",\"description\":\"<p>A practical guide to offering COD safely while keeping settlement times fast and predictable.<\\/p><p>Cash on delivery still drives a large share of online orders, especially for first-time buyers who are not ready to pay up front. The trade-off is a higher return rate and a longer wait for your money.<\\/p><p>Keep it under control by confirming orders over the phone before dispatch, capping COD value for new customers, and choosing a courier with next-day settlement.<\\/p>\"}', '2026-05-22 04:00:00', '2026-05-22 04:00:00'),
(159, 'pickup_page.content', '{\"tag\":\"Schedule A Pickup\",\"heading\":\"Request A Parcel Pick-Up\",\"sub_heading\":\"Tell us where and when \\u2014 one of our riders will arrive to collect your parcel, no need to visit a branch.\",\"side_icon\":\"<i class=\\\"fa-solid fa-headset\\\"><\\/i>\",\"side_heading\":\"Need It Sooner?\",\"side_text\":\"Call us directly to arrange a same-day pickup.\",\"side_phone\":\"+880 1688-042622\"}', '2026-09-01 01:09:45', '2026-09-17 09:48:02'),
(160, 'pickup_page.element', '{\"title\":\"Free pickup for bulk shipments\"}', '2026-09-01 01:09:45', '2026-09-01 01:09:45'),
(161, 'pickup_page.element', '{\"title\":\"Riders arrive within 2\\u20134 hours\"}', '2026-09-01 01:09:45', '2026-09-01 01:09:45'),
(162, 'pickup_page.element', '{\"title\":\"Nationwide & international pickup\"}', '2026-09-01 01:09:45', '2026-09-01 01:09:45'),
(163, 'pickup_page.element', '{\"title\":\"Instant confirmation by SMS & email\"}', '2026-09-01 01:09:45', '2026-09-01 01:09:45'),
(164, 'quote_page.content', '{\"tag\":\"Request A Quick Quote\",\"heading\":\"Tell Us About Your Shipment\",\"sub_heading\":\"Share your parcel details and destination \\u2014 our team will send you the best rate and delivery time as soon as possible.\",\"side_icon\":\"<i class=\\\"fa-solid fa-headset\\\"><\\/i>\",\"side_heading\":\"Need Help Right Away?\",\"side_text\":\"Talk to our support team directly for an instant estimate.\",\"side_phone\":\"+880 1234-567890\"}', '2026-09-01 01:52:23', '2026-09-01 01:52:23'),
(165, 'quote_page.element', '{\"title\":\"Free pickup for bulk shipments\"}', '2026-09-01 01:52:23', '2026-09-01 01:52:23'),
(166, 'quote_page.element', '{\"title\":\"Response within 2 business hours\"}', '2026-09-01 01:52:23', '2026-09-01 01:52:23'),
(167, 'quote_page.element', '{\"title\":\"Transparent pricing, no hidden fees\"}', '2026-09-01 01:52:23', '2026-09-01 01:52:23'),
(168, 'quote_page.element', '{\"title\":\"Domestic & worldwide delivery\"}', '2026-09-01 01:52:23', '2026-09-01 01:52:23'),
(169, 'book_page.content', '{\"tag\":\"Book Your Consignment\",\"heading\":\"Online Shipment Booking\",\"sub_heading\":\"Fill in shipper, consignee and parcel details below and our team will confirm your booking and pickup schedule.\",\"side_icon\":\"<i class=\\\"fa-solid fa-headset\\\"><\\/i>\",\"side_heading\":\"Need Help Booking?\",\"side_text\":\"Our team can complete the booking for you over the phone.\",\"side_phone\":\"+880 1234-567890\"}', '2026-09-01 02:09:47', '2026-09-01 02:09:47'),
(170, 'book_page.element', '{\"title\":\"Confirmation within 1 business hour\"}', '2026-09-01 02:09:47', '2026-09-01 02:09:47'),
(171, 'book_page.element', '{\"title\":\"Prepaid & collect payment options\"}', '2026-09-01 02:09:47', '2026-09-01 02:09:47'),
(172, 'book_page.element', '{\"title\":\"Free pickup for bulk bookings\"}', '2026-09-01 02:09:47', '2026-09-01 02:09:47'),
(173, 'book_page.element', '{\"title\":\"Nationwide & international delivery\"}', '2026-09-01 02:09:47', '2026-09-01 02:09:47');

-- --------------------------------------------------------

--
-- Table structure for table `gateways`
--

CREATE TABLE `gateways` (
  `id` bigint UNSIGNED NOT NULL,
  `form_id` int UNSIGNED NOT NULL DEFAULT '0',
  `code` int DEFAULT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alias` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NULL',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>enable, 2=>disable',
  `gateway_parameters` text COLLATE utf8mb4_general_ci,
  `supported_currencies` text COLLATE utf8mb4_general_ci,
  `crypto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: fiat currency, 1: crypto currency',
  `extra` text COLLATE utf8mb4_general_ci,
  `description` text COLLATE utf8mb4_general_ci,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `form_id`, `code`, `name`, `alias`, `status`, `gateway_parameters`, `supported_currencies`, `crypto`, `extra`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 0, 101, 'Paypal', 'Paypal', 1, '{\"paypal_email\":{\"title\":\"PayPal Email\",\"global\":true,\"value\":\"sb-58ira22618401@business.example.com\"}}', '{\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"TWD\":\"TWD\",\"NZD\":\"NZD\",\"NOK\":\"NOK\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"GBP\":\"GBP\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"USD\":\"$\"}', 0, NULL, NULL, '68ad6c4a8e06b1756195914.png', '2019-09-14 13:14:22', '2025-08-26 02:11:54'),
(2, 0, 102, 'Perfect Money', 'PerfectMoney', 1, '{\"passphrase\":{\"title\":\"ALTERNATE PASSPHRASE\",\"global\":true,\"value\":\"---------------------\"},\"wallet_id\":{\"title\":\"PM Wallet\",\"global\":false,\"value\":\"\"}}', '{\"USD\":\"$\",\"EUR\":\"\\u20ac\"}', 0, NULL, NULL, '68ad6bf7d53731756195831.png', '2019-09-14 13:14:22', '2025-08-26 02:10:31'),
(3, 0, 105, 'PayTM', 'Paytm', 1, '{\"MID\":{\"title\":\"Merchant ID\",\"global\":true,\"value\":\"-----------\"},\"merchant_key\":{\"title\":\"Merchant Key\",\"global\":true,\"value\":\"--------------------\"},\"WEBSITE\":{\"title\":\"Paytm Website\",\"global\":true,\"value\":\"example.com\"},\"INDUSTRY_TYPE_ID\":{\"title\":\"Industry Type\",\"global\":true,\"value\":\"Retail\"},\"CHANNEL_ID\":{\"title\":\"CHANNEL ID\",\"global\":true,\"value\":\"WEB\"},\"transaction_url\":{\"title\":\"Transaction URL\",\"global\":true,\"value\":\"https:\\/\\/pguat.paytm.com\\/oltp-web\\/processTransaction\"},\"transaction_status_url\":{\"title\":\"Transaction STATUS URL\",\"global\":true,\"value\":\"https:\\/\\/pguat.paytm.com\\/paytmchecksum\\/paytmCallback.jsp\"}}', '{\"AUD\":\"AUD\",\"ARS\":\"ARS\",\"BDT\":\"BDT\",\"BRL\":\"BRL\",\"BGN\":\"BGN\",\"CAD\":\"CAD\",\"CLP\":\"CLP\",\"CNY\":\"CNY\",\"COP\":\"COP\",\"HRK\":\"HRK\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EGP\":\"EGP\",\"EUR\":\"EUR\",\"GEL\":\"GEL\",\"GHS\":\"GHS\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"IDR\":\"IDR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"KES\":\"KES\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"MAD\":\"MAD\",\"NPR\":\"NPR\",\"NZD\":\"NZD\",\"NGN\":\"NGN\",\"NOK\":\"NOK\",\"PKR\":\"PKR\",\"PEN\":\"PEN\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"RON\":\"RON\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"ZAR\":\"ZAR\",\"KRW\":\"KRW\",\"LKR\":\"LKR\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"TRY\":\"TRY\",\"UGX\":\"UGX\",\"UAH\":\"UAH\",\"AED\":\"AED\",\"GBP\":\"GBP\",\"USD\":\"USD\",\"VND\":\"VND\",\"XOF\":\"XOF\"}', 0, NULL, NULL, '68ad6c1ac3b1d1756195866.png', '2019-09-14 13:14:22', '2025-08-26 02:11:06'),
(4, 0, 107, 'PayStack', 'Paystack', 1, '{\"public_key\":{\"title\":\"Public key\",\"global\":true,\"value\":\"--------\"},\"secret_key\":{\"title\":\"Secret key\",\"global\":true,\"value\":\"----------------\"}}', '{\"USD\":\"USD\",\"NGN\":\"NGN\"}', 0, '{\"callback\":{\"title\": \"Callback URL\",\"value\":\"ipn.Paystack\"},\"webhook\":{\"title\": \"Webhook URL\",\"value\":\"ipn.Paystack\"}}\r\n', NULL, '68ad6c289ed011756195880.png', '2019-09-14 13:14:22', '2025-08-26 02:11:20'),
(5, 0, 108, 'VoguePay', 'Voguepay', 1, '{\"merchant_id\":{\"title\":\"MERCHANT ID\",\"global\":true,\"value\":\"-------------------\"}}', '{\"USD\":\"USD\",\"GBP\":\"GBP\",\"EUR\":\"EUR\",\"GHS\":\"GHS\",\"NGN\":\"NGN\",\"ZAR\":\"ZAR\"}', 0, NULL, NULL, '68ad6bba02fe21756195770.png', '2019-09-14 13:14:22', '2025-08-26 02:09:30'),
(6, 0, 109, 'Flutterwave', 'Flutterwave', 0, '{\"public_key\":{\"title\":\"Public Key\",\"global\":true,\"value\":\"----------------\"},\"secret_key\":{\"title\":\"Secret Key\",\"global\":true,\"value\":\"-----------------------\"},\"encryption_key\":{\"title\":\"Encryption Key\",\"global\":true,\"value\":\"------------------\"}}', '{\"BIF\":\"BIF\",\"CAD\":\"CAD\",\"CDF\":\"CDF\",\"CVE\":\"CVE\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"GHS\":\"GHS\",\"GMD\":\"GMD\",\"GNF\":\"GNF\",\"KES\":\"KES\",\"LRD\":\"LRD\",\"MWK\":\"MWK\",\"MZN\":\"MZN\",\"NGN\":\"NGN\",\"RWF\":\"RWF\",\"SLL\":\"SLL\",\"STD\":\"STD\",\"TZS\":\"TZS\",\"UGX\":\"UGX\",\"USD\":\"USD\",\"XAF\":\"XAF\",\"XOF\":\"XOF\",\"ZMK\":\"ZMK\",\"ZMW\":\"ZMW\",\"ZWD\":\"ZWD\"}', 0, NULL, NULL, '68ad6c83913901756195971.png', '2019-09-14 13:14:22', '2025-08-26 02:12:51'),
(7, 0, 110, 'RazorPay', 'Razorpay', 1, '{\"key_id\":{\"title\":\"Key Id\",\"global\":true,\"value\":\"------------\"},\"key_secret\":{\"title\":\"Key Secret \",\"global\":true,\"value\":\"--------\"}}', '{\"INR\":\"INR\"}', 0, NULL, NULL, '68ad6beb086241756195819.png', '2019-09-14 13:14:22', '2025-08-26 02:10:19'),
(8, 0, 112, 'Instamojo', 'Instamojo', 1, '{\"api_key\":{\"title\":\"API KEY\",\"global\":true,\"value\":\"------------\"},\"auth_token\":{\"title\":\"Auth Token\",\"global\":true,\"value\":\"---------\"},\"salt\":{\"title\":\"Salt\",\"global\":true,\"value\":\"-------\"}}', '{\"INR\":\"INR\"}', 0, NULL, NULL, '68ad6c7c20a921756195964.png', '2019-09-14 13:14:22', '2025-08-26 02:12:44'),
(9, 0, 503, 'CoinPayments', 'Coinpayments', 0, '{\"public_key\":{\"title\":\"Public Key\",\"global\":true,\"value\":\"---------------\"},\"private_key\":{\"title\":\"Private Key\",\"global\":true,\"value\":\"------------\"},\"merchant_id\":{\"title\":\"Merchant ID\",\"global\":true,\"value\":\"----------------\"}}', '{\"BTC\":\"Bitcoin\",\"BTC.LN\":\"Bitcoin (Lightning Network)\",\"LTC\":\"Litecoin\",\"CPS\":\"CPS Coin\",\"VLX\":\"Velas\",\"APL\":\"Apollo\",\"AYA\":\"Aryacoin\",\"BAD\":\"Badcoin\",\"BCD\":\"Bitcoin Diamond\",\"BCH\":\"Bitcoin Cash\",\"BCN\":\"Bytecoin\",\"BEAM\":\"BEAM\",\"BITB\":\"Bean Cash\",\"BLK\":\"BlackCoin\",\"BSV\":\"Bitcoin SV\",\"BTAD\":\"Bitcoin Adult\",\"BTG\":\"Bitcoin Gold\",\"BTT\":\"BitTorrent\",\"CLOAK\":\"CloakCoin\",\"CLUB\":\"ClubCoin\",\"CRW\":\"Crown\",\"CRYP\":\"CrypticCoin\",\"CRYT\":\"CryTrExCoin\",\"CURE\":\"CureCoin\",\"DASH\":\"DASH\",\"DCR\":\"Decred\",\"DEV\":\"DeviantCoin\",\"DGB\":\"DigiByte\",\"DOGE\":\"Dogecoin\",\"EBST\":\"eBoost\",\"EOS\":\"EOS\",\"ETC\":\"Ether Classic\",\"ETH\":\"Ethereum\",\"ETN\":\"Electroneum\",\"EUNO\":\"EUNO\",\"EXP\":\"EXP\",\"Expanse\":\"Expanse\",\"FLASH\":\"FLASH\",\"GAME\":\"GameCredits\",\"GLC\":\"Goldcoin\",\"GRS\":\"Groestlcoin\",\"KMD\":\"Komodo\",\"LOKI\":\"LOKI\",\"LSK\":\"LSK\",\"MAID\":\"MaidSafeCoin\",\"MUE\":\"MonetaryUnit\",\"NAV\":\"NAV Coin\",\"NEO\":\"NEO\",\"NMC\":\"Namecoin\",\"NVST\":\"NVO Token\",\"NXT\":\"NXT\",\"OMNI\":\"OMNI\",\"PINK\":\"PinkCoin\",\"PIVX\":\"PIVX\",\"POT\":\"PotCoin\",\"PPC\":\"Peercoin\",\"PROC\":\"ProCurrency\",\"PURA\":\"PURA\",\"QTUM\":\"QTUM\",\"RES\":\"Resistance\",\"RVN\":\"Ravencoin\",\"RVR\":\"RevolutionVR\",\"SBD\":\"Steem Dollars\",\"SMART\":\"SmartCash\",\"SOXAX\":\"SOXAX\",\"STEEM\":\"STEEM\",\"STRAT\":\"STRAT\",\"SYS\":\"Syscoin\",\"TPAY\":\"TokenPay\",\"TRIGGERS\":\"Triggers\",\"TRX\":\" TRON\",\"UBQ\":\"Ubiq\",\"UNIT\":\"UniversalCurrency\",\"USDT\":\"Tether USD (Omni Layer)\",\"USDT.BEP20\":\"Tether USD (BSC Chain)\",\"USDT.ERC20\":\"Tether USD (ERC20)\",\"USDT.TRC20\":\"Tether USD (Tron/TRC20)\",\"VTC\":\"Vertcoin\",\"WAVES\":\"Waves\",\"XCP\":\"Counterparty\",\"XEM\":\"NEM\",\"XMR\":\"Monero\",\"XSN\":\"Stakenet\",\"XSR\":\"SucreCoin\",\"XVG\":\"VERGE\",\"XZC\":\"ZCoin\",\"ZEC\":\"ZCash\",\"ZEN\":\"Horizen\"}', 1, NULL, NULL, '68ad6cc15eb401756196033.png', '2019-09-14 13:14:22', '2025-08-26 02:13:53'),
(10, 0, 506, 'Coinbase Commerce', 'CoinbaseCommerce', 0, '{\"api_key\":{\"title\":\"API Key\",\"global\":true,\"value\":\"---------\"},\"secret\":{\"title\":\"Webhook Shared Secret\",\"global\":true,\"value\":\"----------------\"}}', '{\"USD\":\"USD\",\"EUR\":\"EUR\",\"JPY\":\"JPY\",\"GBP\":\"GBP\",\"AUD\":\"AUD\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"CNY\":\"CNY\",\"SEK\":\"SEK\",\"NZD\":\"NZD\",\"MXN\":\"MXN\",\"SGD\":\"SGD\",\"HKD\":\"HKD\",\"NOK\":\"NOK\",\"KRW\":\"KRW\",\"TRY\":\"TRY\",\"RUB\":\"RUB\",\"INR\":\"INR\",\"BRL\":\"BRL\",\"ZAR\":\"ZAR\",\"AED\":\"AED\",\"AFN\":\"AFN\",\"ALL\":\"ALL\",\"AMD\":\"AMD\",\"ANG\":\"ANG\",\"AOA\":\"AOA\",\"ARS\":\"ARS\",\"AWG\":\"AWG\",\"AZN\":\"AZN\",\"BAM\":\"BAM\",\"BBD\":\"BBD\",\"BDT\":\"BDT\",\"BGN\":\"BGN\",\"BHD\":\"BHD\",\"BIF\":\"BIF\",\"BMD\":\"BMD\",\"BND\":\"BND\",\"BOB\":\"BOB\",\"BSD\":\"BSD\",\"BTN\":\"BTN\",\"BWP\":\"BWP\",\"BYN\":\"BYN\",\"BZD\":\"BZD\",\"CDF\":\"CDF\",\"CLF\":\"CLF\",\"CLP\":\"CLP\",\"COP\":\"COP\",\"CRC\":\"CRC\",\"CUC\":\"CUC\",\"CUP\":\"CUP\",\"CVE\":\"CVE\",\"CZK\":\"CZK\",\"DJF\":\"DJF\",\"DKK\":\"DKK\",\"DOP\":\"DOP\",\"DZD\":\"DZD\",\"EGP\":\"EGP\",\"ERN\":\"ERN\",\"ETB\":\"ETB\",\"FJD\":\"FJD\",\"FKP\":\"FKP\",\"GEL\":\"GEL\",\"GGP\":\"GGP\",\"GHS\":\"GHS\",\"GIP\":\"GIP\",\"GMD\":\"GMD\",\"GNF\":\"GNF\",\"GTQ\":\"GTQ\",\"GYD\":\"GYD\",\"HNL\":\"HNL\",\"HRK\":\"HRK\",\"HTG\":\"HTG\",\"HUF\":\"HUF\",\"IDR\":\"IDR\",\"ILS\":\"ILS\",\"IMP\":\"IMP\",\"IQD\":\"IQD\",\"IRR\":\"IRR\",\"ISK\":\"ISK\",\"JEP\":\"JEP\",\"JMD\":\"JMD\",\"JOD\":\"JOD\",\"KES\":\"KES\",\"KGS\":\"KGS\",\"KHR\":\"KHR\",\"KMF\":\"KMF\",\"KPW\":\"KPW\",\"KWD\":\"KWD\",\"KYD\":\"KYD\",\"KZT\":\"KZT\",\"LAK\":\"LAK\",\"LBP\":\"LBP\",\"LKR\":\"LKR\",\"LRD\":\"LRD\",\"LSL\":\"LSL\",\"LYD\":\"LYD\",\"MAD\":\"MAD\",\"MDL\":\"MDL\",\"MGA\":\"MGA\",\"MKD\":\"MKD\",\"MMK\":\"MMK\",\"MNT\":\"MNT\",\"MOP\":\"MOP\",\"MRO\":\"MRO\",\"MUR\":\"MUR\",\"MVR\":\"MVR\",\"MWK\":\"MWK\",\"MYR\":\"MYR\",\"MZN\":\"MZN\",\"NAD\":\"NAD\",\"NGN\":\"NGN\",\"NIO\":\"NIO\",\"NPR\":\"NPR\",\"OMR\":\"OMR\",\"PAB\":\"PAB\",\"PEN\":\"PEN\",\"PGK\":\"PGK\",\"PHP\":\"PHP\",\"PKR\":\"PKR\",\"PLN\":\"PLN\",\"PYG\":\"PYG\",\"QAR\":\"QAR\",\"RON\":\"RON\",\"RSD\":\"RSD\",\"RWF\":\"RWF\",\"SAR\":\"SAR\",\"SBD\":\"SBD\",\"SCR\":\"SCR\",\"SDG\":\"SDG\",\"SHP\":\"SHP\",\"SLL\":\"SLL\",\"SOS\":\"SOS\",\"SRD\":\"SRD\",\"SSP\":\"SSP\",\"STD\":\"STD\",\"SVC\":\"SVC\",\"SYP\":\"SYP\",\"SZL\":\"SZL\",\"THB\":\"THB\",\"TJS\":\"TJS\",\"TMT\":\"TMT\",\"TND\":\"TND\",\"TOP\":\"TOP\",\"TTD\":\"TTD\",\"TWD\":\"TWD\",\"TZS\":\"TZS\",\"UAH\":\"UAH\",\"UGX\":\"UGX\",\"UYU\":\"UYU\",\"UZS\":\"UZS\",\"VEF\":\"VEF\",\"VND\":\"VND\",\"VUV\":\"VUV\",\"WST\":\"WST\",\"XAF\":\"XAF\",\"XAG\":\"XAG\",\"XAU\":\"XAU\",\"XCD\":\"XCD\",\"XDR\":\"XDR\",\"XOF\":\"XOF\",\"XPD\":\"XPD\",\"XPF\":\"XPF\",\"XPT\":\"XPT\",\"YER\":\"YER\",\"ZMW\":\"ZMW\",\"ZWL\":\"ZWL\"}\r\n\r\n', 0, '{\"endpoint\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.CoinbaseCommerce\"}}', NULL, '68ad6af1dab631756195569.png', '2019-09-14 13:14:22', '2025-08-26 03:03:20'),
(11, 0, 113, 'Paypal Express', 'PaypalSdk', 1, '{\"clientId\":{\"title\":\"Paypal Client ID\",\"global\":true,\"value\":\"------------\"},\"clientSecret\":{\"title\":\"Client Secret\",\"global\":true,\"value\":\"-----------\"}}', '{\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"TWD\":\"TWD\",\"NZD\":\"NZD\",\"NOK\":\"NOK\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"GBP\":\"GBP\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"USD\":\"$\"}', 0, NULL, NULL, '68ad6c40c252c1756195904.png', '2019-09-14 13:14:22', '2025-08-26 02:11:44'),
(12, 0, 114, 'Stripe Checkout', 'StripeV3', 1, '{\"secret_key\":{\"title\":\"Secret Key\",\"global\":true,\"value\":\"sk_test_51M8Ks2CL65BWuH7eCBcWsLP2yPfWaLtfJVxG3zfii7cCWJE1izM4jkhucmBSm6izmVtSGZyp0JDYYCVmx9E4WmQY004gfnctzD\"},\"publishable_key\":{\"title\":\"PUBLISHABLE KEY\",\"global\":true,\"value\":\"pk_test_51M8Ks2CL65BWuH7eju6khGxJMpeeFuw2Rwrjr8UYCz6ZnQ3PiFxb1gVu1i1dBto9MQrnjkBimHkFJgNcqsrJHTak0010kCY41h\"},\"end_point\":{\"title\":\"End Point Secret\",\"global\":true,\"value\":\"abcd\"}}', '{\"USD\":\"USD\",\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"HKD\":\"HKD\",\"INR\":\"INR\",\"JPY\":\"JPY\",\"MXN\":\"MXN\",\"MYR\":\"MYR\",\"NOK\":\"NOK\",\"NZD\":\"NZD\",\"PLN\":\"PLN\",\"SEK\":\"SEK\",\"SGD\":\"SGD\"}', 0, '{\"webhook\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.StripeV3\"}}', NULL, '68ad6baf71dc81756195759.png', '2019-09-14 13:14:22', '2025-08-26 02:09:19'),
(49, 21, 1000, 'Bank Transfer', 'bank_transfer', 1, '[]', '[]', 0, NULL, '<p>Transfer funds to our official bank account. Enter the details exactly as shown on your transfer receipt. Bank deposits may take 1–3 business days to appear depending on your bank.</p>', '68ad62d32cb781756193491.png', '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(50, 22, 1001, 'Mobile Money', 'mobile_money', 1, '[]', '[]', 0, NULL, '<p>Please send the deposit to our official mobile money number. Make sure to include the correct transaction reference for quick approval. Mobile money deposits are usually processed within a few hours.</p>', '68ad62c6cdb141756193478.png', '2025-06-29 03:30:33', '2025-09-21 07:21:49'),
(51, 23, 1002, 'Cash Pay', 'cash_pay', 1, '[]', '[]', 0, NULL, '<p><i>Deposit cash directly at our office or approved agent location. Provide the agent name or receipt number for verification. Funds will be credited to your account after confirmation.</i></p>', '68ad62b3590361756193459.png', '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(52, 0, 115, 'Mercado Pago', 'MercadoPago', 1, '{\"access_token\":{\"title\":\"Access Token\",\"global\":true,\"value\":\"APP_USR-7924565816849832-082312-21941521997fab717db925cf1ea2c190-1071840315\"}}', '{\"USD\":\"USD\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"NOK\":\"NOK\",\"PLN\":\"PLN\",\"SEK\":\"SEK\",\"AUD\":\"AUD\",\"NZD\":\"NZD\",\"BRL\":\"BRL\"}', 0, '{\"webhook\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.MercadoPago\"}}', NULL, '68ad6c58c0d201756195928.png', '2019-09-14 13:14:22', '2025-08-26 02:12:08'),
(53, 25, 1003, 'Manual Transfer', 'manual_transfer', 1, '[]', '[]', 0, NULL, '<p><i>Please transfer the deposit amount to the provided account manually. After transferring, submit the details and upload the reference number for quick verification. Processing may take 1–2 business days after admin approval.</i></p>', '68ad62a1206e81756193441.png', '2025-08-13 02:19:07', '2025-09-21 07:23:50');

-- --------------------------------------------------------

--
-- Table structure for table `gateway_currencies`
--

CREATE TABLE `gateway_currencies` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `currency` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `symbol` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `method_code` int DEFAULT NULL,
  `gateway_alias` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `min_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `max_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `percent_charge` decimal(5,2) NOT NULL DEFAULT '0.00',
  `fixed_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gateway_parameter` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gateway_currencies`
--

INSERT INTO `gateway_currencies` (`id`, `name`, `currency`, `symbol`, `method_code`, `gateway_alias`, `min_amount`, `max_amount`, `percent_charge`, `fixed_charge`, `rate`, `image`, `gateway_parameter`, `created_at`, `updated_at`) VALUES
(4, 'Bank Transfer', '$', '', 1000, 'bank_transfer', 1.00000000, 1000.00000000, 1.00, 1.00000000, 1.00000000, NULL, NULL, '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(8, 'Mobile Money', '$', '', 1001, 'mobile_money', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-06-29 03:30:33', '2025-09-21 07:21:49'),
(9, 'Cash Pay', '$', '', 1002, 'cash_pay', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(17, 'Manual Transfer', '$', '', 1003, 'manual_transfer', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-08-13 02:19:07', '2025-09-21 07:23:50'),
(19, 'Paypal - USD', 'USD', '$', 101, 'Paypal', 10.00000000, 1000.00000000, 0.00, 0.00000000, 1.00000000, NULL, '{\"paypal_email\":\"sb-58ira22618401@business.example.com\"}', '2025-08-26 02:11:54', '2025-08-26 02:11:54'),
(20, 'Mercado Pago - CAD', 'CAD', '$', 115, 'MercadoPago', 1.00000000, 1000000.00000000, 0.25, 0.25000000, 1.00000000, NULL, '{\"access_token\":\"APP_USR-7924565816849832-082312-21941521997fab717db925cf1ea2c190-1071840315\"}', '2025-08-26 02:12:08', '2025-08-26 02:12:08'),
(21, 'Bank Transferddddddd', '$$', '', 1004, 'bank_transferddddddd', 1.00000000, 1000000000.00000000, 1.00, 1.00000000, 1.00000000, NULL, NULL, '2025-10-02 04:00:36', '2025-10-02 04:01:00'),
(22, 'Coinbase Commerce - JPY', 'JPY', '₦', 506, 'CoinbaseCommerce', 1.00000000, 10000.00000000, 1.00, 1.00000000, 1.00000000, NULL, '{\"api_key\":\"---------\",\"secret\":\"----------------\"}', '2025-10-02 05:29:15', '2025-10-02 05:29:15');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `site_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cur_text` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'currency text',
  `cur_sym` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'currency symbol',
  `email_from` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_template` text COLLATE utf8mb4_general_ci,
  `sms_body` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sms_from` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `base_color` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `secondary_color` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mail_config` text COLLATE utf8mb4_general_ci COMMENT 'email configuration',
  `sms_config` text COLLATE utf8mb4_general_ci,
  `global_shortcodes` text COLLATE utf8mb4_general_ci,
  `kv` tinyint(1) NOT NULL DEFAULT '0',
  `ev` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'email verification, 0 - dont check, 1 - check',
  `en` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'email notification, 0 - dont send, 1 - send',
  `sv` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'mobile verication, 0 - dont check, 1 - check',
  `sn` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'sms notification, 0 - dont send, 1 - send',
  `force_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `secure_password` tinyint(1) NOT NULL DEFAULT '0',
  `agree` tinyint(1) NOT NULL DEFAULT '0',
  `registration` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: Off	, 1: On',
  `active_template` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_info` text COLLATE utf8mb4_general_ci,
  `socialite_credentials` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_name`, `cur_text`, `cur_sym`, `email_from`, `email_template`, `sms_body`, `sms_from`, `base_color`, `secondary_color`, `mail_config`, `sms_config`, `global_shortcodes`, `kv`, `ev`, `en`, `sv`, `sn`, `force_ssl`, `maintenance_mode`, `secure_password`, `agree`, `registration`, `active_template`, `system_info`, `socialite_credentials`, `created_at`, `updated_at`) VALUES
(1, 'AN Express', 'USD', '$', 'notify@example.com', '<p>Hi {{fullname}} ({{username}}),&nbsp;</p><p>{{message}}</p>', 'Hi {{fullname}} ({{username}}), \r\n{{message}}', 'Minstack', 'ff6600', '0b1f3a', '{\"name\":\"php\"}', '{\"name\":\"clickatell\",\"clickatell\":{\"api_key\":\"==============ck\"},\"infobip\":{\"username\":\"=================in\",\"password\":\"================in\"},\"message_bird\":{\"api_key\":\"=============mb\"},\"nexmo\":{\"api_key\":\"----------------------nx\",\"api_secret\":\"----------------------nx\"},\"sms_broadcast\":{\"username\":\"================sb\",\"password\":\"=================sb\"},\"twilio\":{\"account_sid\":\"-----------------------tw\",\"auth_token\":\"---------------------------tw\",\"from\":\"----------------------tw\"},\"custom\":{\"method\":\"get\",\"url\":\"https:\\/\\/hostname\\/demo-api-v1\",\"headers\":{\"name\":[\"api_key\"],\"value\":[\"test_api 555\"]},\"body\":{\"name\":[\"from_number\"],\"value\":[\"5657545757\"]}}}', '{\n    \"site_name\":\"Name of your site\",\n    \"site_currency\":\"Currency of your site\",\n    \"currency_symbol\":\"Symbol of currency\"\n}', 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 'default', '[]', '{\"google\":{\"client_id\":\"959894800111-743odo92gdre71v9vt1u6pqkc5vo9v3g.apps.googleusercontent.com\",\"client_secret\":\"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\",\"status\":0},\"facebook\":{\"client_id\":\"================\",\"client_secret\":\"==============\",\"status\":0}}', NULL, '2026-08-29 01:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `text_align` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: left to right text align, 1: right to left text align',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: not default language, 1: default language',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `code`, `image`, `text_align`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'English', 'en', '68cfe345448ad1758454597.png', 0, 1, '2020-07-06 03:47:55', '2025-09-21 05:36:37'),
(16, 'Spanish', 'es', '68cfe376103511758454646.jpg', 0, 0, '2025-06-26 00:14:07', '2025-09-21 05:37:26'),
(22, 'Hindi', 'hi', '68cfe36a2dd981758454634.png', 0, 0, '2025-09-21 05:37:14', '2025-09-21 05:37:14');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Header Menu', 'header_menu', '2025-09-16 02:39:26', '2025-09-16 02:39:26'),
(2, 'Useful Links', 'important_link', '2025-09-16 02:39:37', '2025-09-20 03:03:58');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `link_type` tinyint(1) NOT NULL DEFAULT '1',
  `page_id` bigint NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `title`, `link_type`, `page_id`, `url`, `created_at`, `updated_at`) VALUES
(6, 'Privacy Policy', 1, 0, 'policy/privacy-policy/42', '2025-09-20 03:05:05', '2025-09-20 03:05:05'),
(7, 'Terms of Service', 1, 0, 'policy/terms-of-service/43', '2025-09-20 03:05:23', '2025-09-20 03:05:23'),
(8, 'Cookie Policy', 1, 0, 'cookie-policy', '2025-09-20 03:05:37', '2025-09-20 03:05:37'),
(9, 'Pickup Request', 1, 0, 'pickup', '2026-08-30 03:44:23', '2026-08-30 03:44:23'),
(10, 'Get a Quote', 1, 0, 'quote', '2026-08-30 03:44:23', '2026-08-30 03:44:23'),
(11, 'About', 1, 0, 'about', '2026-08-30 03:44:23', '2026-08-30 03:44:23'),
(12, 'Blog', 1, 0, 'blog', '2026-08-30 03:44:23', '2026-08-30 03:44:23'),
(13, 'Contact', 1, 0, 'contact', '2026-08-30 03:44:23', '2026-08-30 03:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `menu_menu_items`
--

CREATE TABLE `menu_menu_items` (
  `id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  `menu_item_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_menu_items`
--

INSERT INTO `menu_menu_items` (`id`, `menu_id`, `menu_item_id`, `created_at`, `updated_at`) VALUES
(14, 2, 6, '2025-09-20 03:05:05', '2025-09-20 03:05:05'),
(15, 2, 7, '2025-09-20 03:05:23', '2025-09-20 03:05:23'),
(16, 2, 8, '2025-09-20 03:05:37', '2025-09-20 03:05:37'),
(28, 1, 9, '2026-09-03 05:35:10', '2026-09-03 05:35:10'),
(29, 1, 10, '2026-09-03 05:35:10', '2026-09-03 05:35:10'),
(30, 1, 11, '2026-09-03 05:35:10', '2026-09-03 05:35:10'),
(31, 1, 12, '2026-09-03 05:35:10', '2026-09-03 05:35:10'),
(33, 1, 13, '2026-09-03 05:35:10', '2026-09-03 05:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2025_07_19_024836_create_menus_table', 1),
(3, '2025_07_19_024852_create_menu_items_table', 2),
(4, '2025_07_19_024918_create_menu_menu_items_table', 3),
(5, '2026_09_01_000000_create_pickup_requests_table', 4),
(6, '2026_09_01_000001_create_quote_requests_table', 5),
(7, '2026_09_01_000002_create_booking_requests_table', 6),
(8, '2026_09_29_000001_add_meta_fields_to_pages_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `notification_logs`
--

CREATE TABLE `notification_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `sender` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sent_from` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sent_to` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci,
  `notification_type` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_logs`
--

INSERT INTO `notification_logs` (`id`, `user_id`, `sender`, `sent_from`, `sent_to`, `subject`, `message`, `notification_type`, `created_at`, `updated_at`) VALUES
(1, 0, 'smtp', 'info@example.com', 'riasadrion@gmail.com', 'SMTP Configuration Success', '<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\r\n  <!--[if !mso]><!-->\r\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n  <!--<![endif]-->\r\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n  <title></title>\r\n  <style type=\"text/css\">\r\n.ReadMsgBody { width: 100%; background-color: #ffffff; }\r\n.ExternalClass { width: 100%; background-color: #ffffff; }\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }\r\nhtml { width: 100%; }\r\nbody { -webkit-text-size-adjust: none; -ms-text-size-adjust: none; margin: 0; padding: 0; }\r\ntable { border-spacing: 0; table-layout: fixed; margin: 0 auto;border-collapse: collapse; }\r\ntable table table { table-layout: auto; }\r\n.yshortcuts a { border-bottom: none !important; }\r\nimg:hover { opacity: 0.9 !important; }\r\na { color: #0087ff; text-decoration: none; }\r\n.textbutton a { font-family: \'open sans\', arial, sans-serif !important;}\r\n.btn-link a { color:#FFFFFF !important;}\r\n\r\n@media only screen and (max-width: 480px) {\r\nbody { width: auto !important; }\r\n*[class=\"table-inner\"] { width: 90% !important; text-align: center !important; }\r\n*[class=\"table-full\"] { width: 100% !important; text-align: center !important; }\r\n/* image */\r\nimg[class=\"img1\"] { width: 100% !important; height: auto !important; }\r\n}\r\n</style>\r\n\r\n\r\n\r\n  <table bgcolor=\"#414a51\" width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n    <tbody><tr>\r\n      <td height=\"50\"></td>\r\n    </tr>\r\n    <tr>\r\n      <td align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n          <tbody><tr>\r\n            <td align=\"center\" width=\"600\">\r\n              <!--header-->\r\n              <table class=\"table-inner\" width=\"95%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                <tbody><tr>\r\n                  <td bgcolor=\"#0087ff\" style=\"border-top-left-radius:6px; border-top-right-radius:6px;text-align:center;vertical-align:top;font-size:0;\" align=\"center\">\r\n                    <table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td align=\"center\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#FFFFFF; font-size:16px; font-weight: bold;\">System Mail</td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n              <!--end header-->\r\n              <table class=\"table-inner\" width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n                  <td bgcolor=\"#FFFFFF\" align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n                    <table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"35\"></td>\r\n                      </tr>\r\n                      <!--logo-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"vertical-align:top;font-size:0;\">\r\n                          <a href=\"#\">\r\n                            <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\" src=\"https://i.imgur.com/K2fIRda.png\" alt=\"img\">\r\n                          </a>\r\n                        </td>\r\n                      </tr>\r\n                      <!--end logo-->\r\n                      <tr>\r\n                        <td height=\"40\"></td>\r\n                      </tr>\r\n                      <!--headline-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"font-family: \'Open Sans\', Arial, sans-serif; font-size: 22px;color:#414a51;font-weight: bold;\">Hello riasadrion (riasadrion@gmail.com)</td>\r\n                      </tr>\r\n                      <!--end headline-->\r\n                      <tr>\r\n                        <td align=\"center\" style=\"text-align:center;vertical-align:top;font-size:0;\">\r\n                          <table width=\"40\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n                            <tbody><tr>\r\n                              <td height=\"20\" style=\" border-bottom:3px solid #0087ff;\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                      </tr>\r\n                      <tr>\r\n                        <td height=\"20\"></td>\r\n                      </tr>\r\n                      <!--content-->\r\n                      <tr>\r\n                        <td align=\"left\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#7f8c8d; font-size:16px; line-height: 28px;\">Your email notification setting is configured successfully for MinStack</td>\r\n                      </tr>\r\n                      <!--end content-->\r\n                      <tr>\r\n                        <td height=\"40\"></td>\r\n                      </tr>\r\n              \r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td height=\"45\" align=\"center\" bgcolor=\"#f4f4f4\" style=\"border-bottom-left-radius:6px;border-bottom-right-radius:6px;\">\r\n                    <table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                      <tbody><tr>\r\n                        <td height=\"10\"></td>\r\n                      </tr>\r\n                      <!--preference-->\r\n                      <tr>\r\n                        <td class=\"preference-link\" align=\"center\" style=\"font-family: \'Open sans\', Arial, sans-serif; color:#95a5a6; font-size:14px;\">\r\n                          © 2022&nbsp;<a href=\"#\">MinStack</a>&nbsp;. All Rights Reserved. \r\n                        </td>\r\n                      </tr>\r\n                      <!--end preference-->\r\n                      <tr>\r\n                        <td height=\"10\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <tr>\r\n      <td height=\"60\"></td>\r\n    </tr>\r\n  </tbody></table>', 'email', '2023-01-21 07:41:43', '2023-01-21 07:41:43'),
(2, 0, 'smtp', 'no-reply@baronmeddy.com', 'mdrsdrion@gmail.com', 'SMTP Configuration Success', '<p>Hi mdrsdrion (mdrsdrion@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2023-12-12 13:17:41', '2023-12-12 13:17:41'),
(3, 0, 'smtp', 'no-reply@baronmeddy.com', 'mdrsdrion@gmail.com', 'SMTP Configuration Success', '<p>Hi mdrsdrion (mdrsdrion@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2023-12-12 13:18:48', '2023-12-12 13:18:48'),
(4, 0, 'smtp', 'no-reply@baronmeddy.com', 'baronmeddy@gmail.com', 'SMTP Configuration Success', '<p>Hi baronmeddy (baronmeddy@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2023-12-12 13:20:15', '2023-12-12 13:20:15'),
(5, 0, 'smtp', 'no-reply@baronmeddy.com', 'mdrsdrion@gmail.com', 'SMTP Configuration Success', '<p>Hi mdrsdrion (mdrsdrion@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2023-12-12 13:20:31', '2023-12-12 13:20:31'),
(6, 8, 'php', 'notify@example.com', 'test@mail.com', 'Please verify your email address', '<p>Hi John Doe (testuser),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;924468</span></font></div></div></p>', 'email', '2025-06-25 04:41:27', '2025-06-25 04:41:27'),
(7, 8, 'php', 'notify@example.com', 'user@site.com', 'Password Reset', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-06-28 10:28:21 AM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">793617</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-06-28 04:28:22', '2025-06-28 04:28:22'),
(8, 8, 'php', 'notify@example.com', 'user@site.com', 'Password Reset', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-06-28 10:29:22 AM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">349478</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-06-28 04:29:22', '2025-06-28 04:29:22'),
(9, 8, 'php', 'notify@example.com', 'user@site.com', 'You have reset your password', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">2025-06-28 10:29:56 AM</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p></p>', 'email', '2025-06-28 04:29:57', '2025-06-28 04:29:57'),
(10, 0, 'php', 'notify@example.com', 'rajib@gmail.com', 'Test message', '<p>Hi rajib (rajib@gmail.com),&nbsp;</p><p><p>faaa</p></p>', 'email', '2025-06-29 23:50:17', '2025-06-29 23:50:17'),
(11, 8, 'php', 'notify@example.com', 'user@site.com', 'Test message', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p>aafafaf</p>', 'email', '2025-06-30 00:52:43', '2025-06-30 00:52:43'),
(12, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'Test message', '<p>Hi KB Saul (testuser123),&nbsp;</p><p>aafafaf</p>', 'email', '2025-06-30 00:52:47', '2025-06-30 00:52:47'),
(13, 20, 'php', 'notify@example.com', 'user6@site.com', 'Test message', '<p>Hi tesos tesos (username6),&nbsp;</p><p>aafafaf</p>', 'email', '2025-06-30 00:52:50', '2025-06-30 00:52:50'),
(14, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'Test message', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p>aafafaf</p>', 'email', '2025-06-30 00:52:54', '2025-06-30 00:52:54'),
(15, 8, 'php', 'notify@example.com', 'user@site.com', 'Test message', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:11', '2025-06-30 01:21:11'),
(16, 9, 'php', 'notify@example.com', 'user2@site.com', 'Test message', '<p>Hi User Fring J (username2),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:11', '2025-06-30 01:21:11'),
(17, 11, 'php', 'notify@example.com', 'user457@site.com', 'Test message', '<p>Hi user44 Poyos Harmanos (username3),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:11', '2025-06-30 01:21:11'),
(18, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'Test message', '<p>Hi KB Saul (testuser123),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:11', '2025-06-30 01:21:11'),
(19, 17, 'php', 'notify@example.com', 'user990@site.com', 'Test message', '<p>Hi Test Jimmy Miguel (testuser55),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:12', '2025-06-30 01:21:12'),
(20, 18, 'php', 'notify@example.com', 'user99@site.com', 'Test message', '<p>Hi User Kim Wexlar (username33),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:14', '2025-06-30 01:21:14'),
(21, 19, 'php', 'notify@example.com', 'user5@site.com', 'Test message', '<p>Hi Hamlin Hamlin (username5),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:14', '2025-06-30 01:21:14'),
(22, 20, 'php', 'notify@example.com', 'user6@site.com', 'Test message', '<p>Hi tesos tesos (username6),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:14', '2025-06-30 01:21:14'),
(23, 22, 'php', 'notify@example.com', 'test@mail.com', 'Test message', '<p>Hi Alex Smith (testuser),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:14', '2025-06-30 01:21:14'),
(24, 23, 'php', 'notify@example.com', 'myname5587@myname5587.myname5587', 'Test message', '<p>Hi C. Varga (testuser33),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:14', '2025-06-30 01:21:14'),
(25, 24, 'php', 'notify@example.com', 'mosta@gmail.com', 'Test message', '<p>Hi DCM Wexlar (jcole5950),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:17', '2025-06-30 01:21:17'),
(26, 25, 'php', 'notify@example.com', 'mostas@gmail.com', 'Test message', '<p>Hi Chloe Hoxel (moscingle),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:17', '2025-06-30 01:21:17'),
(27, 26, 'php', 'notify@example.com', 'mosta3@gmail.com', 'Test message', '<p>Hi Ken Wallace (moscingle3),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:17', '2025-06-30 01:21:17'),
(28, 27, 'php', 'notify@example.com', 'testuser5588@gmail.com', 'Test message', '<p>Hi Graciela A. Romano\n (tes77788),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:17', '2025-06-30 01:21:17'),
(29, 28, 'php', 'notify@example.com', 'gasaf@amimail.com', 'Test message', '<p>Hi Ken Morales (fajavidi),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:17', '2025-06-30 01:21:17'),
(30, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'Test message', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:20', '2025-06-30 01:21:20'),
(31, 30, 'php', 'notify@example.com', 'fevu@amimail.com', 'Test message', '<p>Hi Pearl Garrish (lalosalamanca),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:20', '2025-06-30 01:21:20'),
(32, 31, 'php', 'notify@example.com', 'user879@gmail.com', 'Test message', '<p>Hi John Havier (gusfring),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:20', '2025-06-30 01:21:20'),
(33, 32, 'php', 'notify@example.com', 'testuser1@gmail.com', 'Test message', '<p>Hi tesos tesos (testuser1),&nbsp;</p><p>test</p>', 'email', '2025-06-30 01:21:20', '2025-06-30 01:21:20'),
(34, 8, 'php', 'notify@example.com', 'user@site.com', 'aaf', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p>afafaf</p>', 'email', '2025-06-30 02:39:08', '2025-06-30 02:39:08'),
(35, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'aaf', '<p>Hi KB Saul (testuser123),&nbsp;</p><p>afafaf</p>', 'email', '2025-06-30 02:39:08', '2025-06-30 02:39:08'),
(36, 20, 'php', 'notify@example.com', 'user6@site.com', 'aaf', '<p>Hi tesos tesos (username6),&nbsp;</p><p>afafaf</p>', 'email', '2025-06-30 02:39:08', '2025-06-30 02:39:08'),
(37, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'aaf', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p>afafaf</p>', 'email', '2025-06-30 02:39:08', '2025-06-30 02:39:08'),
(38, 8, 'php', 'notify@example.com', 'user@site.com', 'Test message', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:33', '2025-06-30 02:39:33'),
(39, 9, 'php', 'notify@example.com', 'user2@site.com', 'Test message', '<p>Hi User Fring J (username2),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:33', '2025-06-30 02:39:33'),
(40, 11, 'php', 'notify@example.com', 'user457@site.com', 'Test message', '<p>Hi user44 Poyos Harmanos (username3),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:33', '2025-06-30 02:39:33'),
(41, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'Test message', '<p>Hi KB Saul (testuser123),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:34', '2025-06-30 02:39:34'),
(42, 17, 'php', 'notify@example.com', 'user990@site.com', 'Test message', '<p>Hi Test Jimmy Miguel (testuser55),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:34', '2025-06-30 02:39:34'),
(43, 18, 'php', 'notify@example.com', 'user99@site.com', 'Test message', '<p>Hi User Kim Wexlar (username33),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:37', '2025-06-30 02:39:37'),
(44, 19, 'php', 'notify@example.com', 'user5@site.com', 'Test message', '<p>Hi Hamlin Hamlin (username5),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:37', '2025-06-30 02:39:37'),
(45, 20, 'php', 'notify@example.com', 'user6@site.com', 'Test message', '<p>Hi tesos tesos (username6),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:37', '2025-06-30 02:39:37'),
(46, 22, 'php', 'notify@example.com', 'test@mail.com', 'Test message', '<p>Hi Alex Smith (testuser),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:38', '2025-06-30 02:39:38'),
(47, 23, 'php', 'notify@example.com', 'myname5587@myname5587.myname5587', 'Test message', '<p>Hi C. Varga (testuser33),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:38', '2025-06-30 02:39:38'),
(48, 24, 'php', 'notify@example.com', 'mosta@gmail.com', 'Test message', '<p>Hi DCM Wexlar (jcole5950),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:41', '2025-06-30 02:39:41'),
(49, 25, 'php', 'notify@example.com', 'mostas@gmail.com', 'Test message', '<p>Hi Chloe Hoxel (moscingle),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:41', '2025-06-30 02:39:41'),
(50, 26, 'php', 'notify@example.com', 'mosta3@gmail.com', 'Test message', '<p>Hi Ken Wallace (moscingle3),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:41', '2025-06-30 02:39:41'),
(51, 27, 'php', 'notify@example.com', 'testuser5588@gmail.com', 'Test message', '<p>Hi Graciela A. Romano\n (tes77788),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:42', '2025-06-30 02:39:42'),
(52, 28, 'php', 'notify@example.com', 'gasaf@amimail.com', 'Test message', '<p>Hi Ken Morales (fajavidi),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:42', '2025-06-30 02:39:42'),
(53, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'Test message', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:45', '2025-06-30 02:39:45'),
(54, 30, 'php', 'notify@example.com', 'fevu@amimail.com', 'Test message', '<p>Hi Pearl Garrish (lalosalamanca),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:45', '2025-06-30 02:39:45'),
(55, 31, 'php', 'notify@example.com', 'user879@gmail.com', 'Test message', '<p>Hi John Havier (gusfring),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:45', '2025-06-30 02:39:45'),
(56, 32, 'php', 'notify@example.com', 'testuser1@gmail.com', 'Test message', '<p>Hi tesos tesos (testuser1),&nbsp;</p><p>afafafaf</p>', 'email', '2025-06-30 02:39:46', '2025-06-30 02:39:46'),
(57, 8, 'php', 'notify@example.com', 'user@site.com', 'Your Account has been Credited', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div><div style=\"font-family: Montserrat, sans-serif;\">13.00 USD has been added to your account .</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : JU91N4WXPY1M</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Current Balance is :&nbsp;</span><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">14,730.56&nbsp; USD&nbsp;</span></font><br></div><div><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></font></div><div>Admin note:&nbsp;<span style=\"color: rgb(33, 37, 41); font-size: 12px; font-weight: 600; white-space: nowrap; text-align: var(--bs-body-text-align);\">add</span></div></p>', 'email', '2025-06-30 04:38:44', '2025-06-30 04:38:44'),
(58, 8, 'php', 'notify@example.com', 'user@site.com', 'Your Account has been Debited', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">13.00 USD has been subtracted from your account .</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : QBMDJ9OOCEF9</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Current Balance is :&nbsp;</span><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">14,717.56&nbsp; USD</span></font><br><div><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></font></div><div>Admin Note: 13</div></p>', 'email', '2025-06-30 04:38:57', '2025-06-30 04:38:57'),
(59, 8, 'php', 'notify@example.com', 'user@site.com', 'Password Reset', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-07-02 12:14:09 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Firefox</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">251321</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-07-02 06:14:10', '2025-07-02 06:14:10'),
(60, 8, 'php', 'notify@example.com', 'user@site.com', 'You have reset your password', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Firefox</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">2025-07-02 12:14:55 PM</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p></p>', 'email', '2025-07-02 06:14:55', '2025-07-02 06:14:55'),
(61, 8, 'php', 'notify@example.com', 'user@site.com', 'Withdraw Request has been Rejected and your money is refunded to your account', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">10,000.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been Rejected.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 10,000.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">3.00 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You should get: 97.00 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : 9JO7WE2YMWJY</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">----</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\"><br></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\">10,000.00 {{currency}} has been&nbsp;<span style=\"font-weight: bolder;\">refunded&nbsp;</span>to your account and your current Balance is&nbsp;<span style=\"font-weight: bolder;\">24,717.56</span><span style=\"font-weight: bolder;\">&nbsp;USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Rejection :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">test</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br><br><br></div><div></div><div></div></p>', 'email', '2025-07-02 07:11:44', '2025-07-02 07:11:44'),
(62, 8, 'php', 'notify@example.com', 'user@site.com', 'Reply Support Ticket', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div><p><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\">A member from our support team has replied to the following ticket:</span></span></p><p><span style=\"font-weight: bolder;\"><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\"><br></span></span></span></p><p><span style=\"font-weight: bolder;\">[Ticket#754432] test<br><br>Click here to reply:&nbsp; http://localhost/wstacks_12/ticket/view/754432</span></p><p>----------------------------------------------</p><p>Here is the reply :<br></p><p>teast<br></p></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-02 07:31:10', '2025-07-02 07:31:10'),
(63, 8, 'php', 'notify@example.com', 'user@site.com', 'Reply Support Ticket', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div><p><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\">A member from our support team has replied to the following ticket:</span></span></p><p><span style=\"font-weight: bolder;\"><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\"><br></span></span></span></p><p><span style=\"font-weight: bolder;\">[Ticket#754432] test<br><br>Click here to reply:&nbsp; http://localhost/wstacks_12/ticket/view/754432</span></p><p>----------------------------------------------</p><p>Here is the reply :<br></p><p>test<br></p></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-02 07:46:08', '2025-07-02 07:46:08'),
(64, 8, 'php', 'notify@example.com', 'user@site.com', 'Reply Support Ticket', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div><p><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\">A member from our support team has replied to the following ticket:</span></span></p><p><span style=\"font-weight: bolder;\"><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\"><br></span></span></span></p><p><span style=\"font-weight: bolder;\">[Ticket#754432] test<br><br>Click here to reply:&nbsp; http://localhost/wstacks_12/ticket/view/754432</span></p><p>----------------------------------------------</p><p>Here is the reply :<br></p><p>test<br></p></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-02 07:46:21', '2025-07-02 07:46:21'),
(65, 33, 'php', 'notify@example.com', 'testuser@site.com', 'Your Account has been Credited', '<p>Hi Alex John (testuserd),&nbsp;</p><p><div><div style=\"font-family: Montserrat, sans-serif;\">10.00 USD has been added to your account .</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : YUGQ2OGJV2BH</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Current Balance is :&nbsp;</span><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">10.00&nbsp; USD&nbsp;</span></font><br></div><div><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></font></div><div>Admin note:&nbsp;<span style=\"color: rgb(33, 37, 41); font-size: 12px; font-weight: 600; white-space: nowrap; text-align: var(--bs-body-text-align);\">test</span></div></p>', 'email', '2025-07-07 00:47:49', '2025-07-07 00:47:49'),
(66, 0, 'php', 'notify@example.com', 'rajib@gmail.com', 'Test message', '<p>Hi rajib (rajib@gmail.com),&nbsp;</p><p><p>fafafa</p></p>', 'email', '2025-07-07 04:06:50', '2025-07-07 04:06:50'),
(67, 0, 'php', 'notify@example.com', 'test1@gmail.com', 'Test message', '<p>Hi test1 (test1@gmail.com),&nbsp;</p><p><p>fafafa</p></p>', 'email', '2025-07-07 04:06:50', '2025-07-07 04:06:50'),
(68, 0, 'php', 'notify@example.com', 'test2@gmail.com', 'Test message', '<p>Hi test2 (test2@gmail.com),&nbsp;</p><p><p>fafafa</p></p>', 'email', '2025-07-07 04:06:50', '2025-07-07 04:06:50'),
(69, 8, 'php', 'notify@example.com', 'user@site.com', 'Withdraw Request Submitted Successfully', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">10.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been submitted Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 10.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.20 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 8.80 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : YNQH4BFAQ29S</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">24,707.56 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br></div></p>', 'email', '2025-07-07 05:55:08', '2025-07-07 05:55:08'),
(70, 8, 'php', 'notify@example.com', 'user@site.com', 'Deposit Request Submitted Successfully', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">10.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Bank Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 10.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.10 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 11.10 $<br></div><div>Pay via :&nbsp; Bank Transfer</div><div><br></div><div>Transaction Number : U5FVD9V6KNN2</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-07 05:56:35', '2025-07-07 05:56:35'),
(71, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Please verify your email address', '<p>Hi @rajibhossain (rajibhossain),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;746218</span></font></div></div></p>', 'email', '2025-07-08 00:27:51', '2025-07-08 00:27:51'),
(72, 0, 'php', 'notify@example.com', 'user@gmail.com', 'PHP Configuration Success', '<p>Hi user (user@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2025-07-08 00:42:16', '2025-07-08 00:42:16'),
(73, 34, 'custom', 'notify@example.com', '9301521471117', 'Verify Your Mobile Number', 'Hi @rajibhossain (rajibhossain), \r\nYour phone verification code is: 403625', 'sms', '2025-07-08 01:04:30', '2025-07-08 01:04:30'),
(74, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 1,000.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">3.50 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 1,003.50 $<br></div><div>Pay via :&nbsp; Mobile Money</div><div><br></div><div>Transaction Number : 2ZKQVKQ5Y232</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-08 01:06:01', '2025-07-08 01:06:01'),
(75, 34, 'custom', 'notify@example.com', '9301521471117', 'Deposit Request Submitted Successfully', 'Hi Rajib Hossain (rajibhossain), \r\n1,000.00 USD Deposit requested by Mobile Money. Charge: 3.50 . Trx: 2ZKQVKQ5Y232', 'sms', '2025-07-08 01:06:04', '2025-07-08 01:06:04'),
(76, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Your Deposit is Approved', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 1,000.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">3.50 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 1,003.50 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Mobile Money</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : 2ZKQVKQ5Y232</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-07-08 01:06:30', '2025-07-08 01:06:30'),
(77, 34, 'custom', 'notify@example.com', '9301521471117', 'Your Deposit is Approved', 'Hi Rajib Hossain (rajibhossain), \r\nAdmin Approve Your 1,000.00 USD payment request by Mobile Money transaction : 2ZKQVKQ5Y232', 'sms', '2025-07-08 01:06:33', '2025-07-08 01:06:33'),
(78, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 1,000.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">3.50 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 1,003.50 $<br></div><div>Pay via :&nbsp; Mobile Money</div><div><br></div><div>Transaction Number : 7U2997PFGCRM</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-08 01:11:00', '2025-07-08 01:11:00'),
(79, 34, 'custom', 'notify@example.com', '9301521471117', 'Deposit Request Submitted Successfully', 'Hi Rajib Hossain (rajibhossain), \r\n1,000.00 USD Deposit requested by Mobile Money. Charge: 3.50 . Trx: 7U2997PFGCRM', 'sms', '2025-07-08 01:11:02', '2025-07-08 01:11:02'),
(80, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Your Deposit Request is Rejected', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money has been rejected</span>.<span style=\"font-weight: bolder;\"><br></span></div><div><br></div><div><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 1,003.50 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Mobile Money</div><div style=\"font-family: Montserrat, sans-serif;\">Charge: 3.50</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number was : 7U2997PFGCRM</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">if you have any queries, feel free to contact us.<br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><br><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Fake transaction</span><br></p>', 'email', '2025-07-08 01:11:28', '2025-07-08 01:11:28'),
(81, 34, 'custom', 'notify@example.com', '9301521471117', 'Your Deposit Request is Rejected', 'Hi Rajib Hossain (rajibhossain), \r\nAdmin Rejected Your 1,000.00 USD payment request by Mobile Money\r\n\r\nFake transaction', 'sms', '2025-07-08 01:11:31', '2025-07-08 01:11:31'),
(82, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">100.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 100.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.25 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 101.25 $<br></div><div>Pay via :&nbsp; Mobile Money</div><div><br></div><div>Transaction Number : DTKN93BOY9T3</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-07-08 01:12:09', '2025-07-08 01:12:09'),
(83, 34, 'custom', 'notify@example.com', '9301521471117', 'Deposit Request Submitted Successfully', 'Hi Rajib Hossain (rajibhossain), \r\n100.00 USD Deposit requested by Mobile Money. Charge: 1.25 . Trx: DTKN93BOY9T3', 'sms', '2025-07-08 01:12:12', '2025-07-08 01:12:12'),
(84, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Your Deposit is Approved', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">100.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Mobile Money&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 100.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.25 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 101.25 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Mobile Money</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : DTKN93BOY9T3</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,100.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-07-08 01:12:46', '2025-07-08 01:12:46'),
(85, 34, 'custom', 'notify@example.com', '9301521471117', 'Your Deposit is Approved', 'Hi Rajib Hossain (rajibhossain), \r\nAdmin Approve Your 100.00 USD payment request by Mobile Money transaction : DTKN93BOY9T3', 'sms', '2025-07-08 01:12:49', '2025-07-08 01:12:49'),
(86, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Withdraw Request Submitted Successfully', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">10.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been submitted Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 10.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.20 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 8.80 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : 5ZGMCXSPTG73</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,090.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br></div></p>', 'email', '2025-07-08 01:15:00', '2025-07-08 01:15:00'),
(87, 34, 'custom', 'notify@example.com', '9301521471117', 'Withdraw Request Submitted Successfully', 'Hi Rajib Hossain (rajibhossain), \r\n10.00 USD withdraw requested by Tranfer from Bank. You will get 8.80 USD Trx: 5ZGMCXSPTG73', 'sms', '2025-07-08 01:15:03', '2025-07-08 01:15:03');
INSERT INTO `notification_logs` (`id`, `user_id`, `sender`, `sent_from`, `sent_to`, `subject`, `message`, `notification_type`, `created_at`, `updated_at`) VALUES
(88, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Withdraw Request has been Processed and your money is sent', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">10.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been Processed Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 10.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.20 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 8.80 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : 5ZGMCXSPTG73</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Processed Payment :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">Transaction successfull</span></font></div></p>', 'email', '2025-07-08 01:15:34', '2025-07-08 01:15:34'),
(89, 34, 'custom', 'notify@example.com', '9301521471117', 'Withdraw Request has been Processed and your money is sent', 'Hi Rajib Hossain (rajibhossain), \r\nAdmin Approve Your 10.00 USD withdraw request by Tranfer from Bank. Transaction 5ZGMCXSPTG73', 'sms', '2025-07-08 01:15:37', '2025-07-08 01:15:37'),
(90, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Withdraw Request Submitted Successfully', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">90.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been submitted Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 90.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">2.80 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 87.20 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : JM1BUP8HF717</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,000.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br></div></p>', 'email', '2025-07-08 01:16:50', '2025-07-08 01:16:50'),
(91, 34, 'custom', 'notify@example.com', '9301521471117', 'Withdraw Request Submitted Successfully', 'Hi Rajib Hossain (rajibhossain), \r\n90.00 USD withdraw requested by Tranfer from Bank. You will get 87.20 USD Trx: JM1BUP8HF717', 'sms', '2025-07-08 01:16:52', '2025-07-08 01:16:52'),
(92, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Withdraw Request has been Rejected and your money is refunded to your account', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">90.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Tranfer from Bank&nbsp;</span>has been Rejected.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 90.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">2.80 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">You should get: 87.20 USD<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Tranfer from Bank</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : JM1BUP8HF717</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">----</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\"><br></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\">90.00 {{currency}} has been&nbsp;<span style=\"font-weight: bolder;\">refunded&nbsp;</span>to your account and your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,090.00</span><span style=\"font-weight: bolder;\">&nbsp;USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Rejection :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">Fake transaction</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br><br><br></div><div></div><div></div></p>', 'email', '2025-07-08 01:17:53', '2025-07-08 01:17:53'),
(93, 34, 'custom', 'notify@example.com', '9301521471117', 'Withdraw Request has been Rejected and your money is refunded to your account', 'Hi Rajib Hossain (rajibhossain), \r\nAdmin Rejected Your 90.00 USD withdraw request. Your Main Balance 1,090.00  Tranfer from Bank , Transaction JM1BUP8HF717', 'sms', '2025-07-08 01:17:56', '2025-07-08 01:17:56'),
(94, 8, 'php', 'notify@example.com', 'user@site.com', 'test', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:18', '2025-07-24 06:22:18'),
(95, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'test', '<p>Hi KB Saul (testuser123),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:21', '2025-07-24 06:22:21'),
(96, 20, 'php', 'notify@example.com', 'user6@site.com', 'test', '<p>Hi tesos tesos (username6),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:24', '2025-07-24 06:22:24'),
(97, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'test', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:27', '2025-07-24 06:22:27'),
(98, 33, 'php', 'notify@example.com', 'testuser@site.com', 'test', '<p>Hi Alex John (testuserd),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:29', '2025-07-24 06:22:29'),
(99, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'test', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><p>test</p></p>', 'email', '2025-07-24 06:22:32', '2025-07-24 06:22:32'),
(100, 8, 'custom', 'notify@example.com', '880123456', '', 'Hi User Hingle May (hinglemay), \r\nTest', 'sms', '2025-07-24 06:28:47', '2025-07-24 06:28:47'),
(101, 13, 'custom', 'notify@example.com', '1268654254541', '', 'Hi KB Saul (testuser123), \r\nTest', 'sms', '2025-07-24 06:28:49', '2025-07-24 06:28:49'),
(102, 20, 'custom', 'notify@example.com', '936546334', '', 'Hi tesos tesos (username6), \r\nTest', 'sms', '2025-07-24 06:28:52', '2025-07-24 06:28:52'),
(103, 29, 'custom', 'notify@example.com', '18695946542145', '', 'Hi Anthony  J. (michbarry), \r\nTest', 'sms', '2025-07-24 06:28:57', '2025-07-24 06:28:57'),
(104, 33, 'custom', 'notify@example.com', '880123456555', '', 'Hi Alex John (testuserd), \r\nTest', 'sms', '2025-07-24 06:28:59', '2025-07-24 06:28:59'),
(105, 34, 'custom', 'notify@example.com', '9301521471117', '', 'Hi Rajib Hossain (rajibhossain), \r\nTest', 'sms', '2025-07-24 06:29:02', '2025-07-24 06:29:02'),
(106, 8, 'php', 'notify@example.com', 'user@site.com', 'Test Email Sent', '<p>Hi User Hingle May (hinglemay),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:30', '2025-07-24 06:29:30'),
(107, 13, 'php', 'notify@example.com', 'testuser123@gmail.com', 'Test Email Sent', '<p>Hi KB Saul (testuser123),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:30', '2025-07-24 06:29:30'),
(108, 20, 'php', 'notify@example.com', 'user6@site.com', 'Test Email Sent', '<p>Hi tesos tesos (username6),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:30', '2025-07-24 06:29:30'),
(109, 29, 'php', 'notify@example.com', 'fyjify@amimail.com', 'Test Email Sent', '<p>Hi Anthony  J. (michbarry),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:33', '2025-07-24 06:29:33'),
(110, 33, 'php', 'notify@example.com', 'testuser@site.com', 'Test Email Sent', '<p>Hi Alex John (testuserd),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:33', '2025-07-24 06:29:33'),
(111, 34, 'php', 'notify@example.com', 'rajib@gmail.com', 'Test Email Sent', '<p>Hi Rajib Hossain (rajibhossain),&nbsp;</p><p><p>Test Email Sent</p></p>', 'email', '2025-07-24 06:29:33', '2025-07-24 06:29:33'),
(112, 8, 'custom', 'notify@example.com', '880123456', '', 'Hi User Hingle May (hinglemay), \r\nTest SMS Sent', 'sms', '2025-07-24 06:29:56', '2025-07-24 06:29:56'),
(113, 13, 'custom', 'notify@example.com', '1268654254541', '', 'Hi KB Saul (testuser123), \r\nTest SMS Sent', 'sms', '2025-07-24 06:30:01', '2025-07-24 06:30:01'),
(114, 20, 'custom', 'notify@example.com', '936546334', '', 'Hi tesos tesos (username6), \r\nTest SMS Sent', 'sms', '2025-07-24 06:30:07', '2025-07-24 06:30:07'),
(115, 29, 'custom', 'notify@example.com', '18695946542145', '', 'Hi Anthony  J. (michbarry), \r\nTest SMS Sent', 'sms', '2025-07-24 06:30:12', '2025-07-24 06:30:12'),
(116, 33, 'custom', 'notify@example.com', '880123456555', '', 'Hi Alex John (testuserd), \r\nTest SMS Sent', 'sms', '2025-07-24 06:30:17', '2025-07-24 06:30:17'),
(117, 34, 'custom', 'notify@example.com', '9301521471117', '', 'Hi Rajib Hossain (rajibhossain), \r\nTest SMS Sent', 'sms', '2025-07-24 06:30:22', '2025-07-24 06:30:22'),
(118, 0, 'php', 'notify@example.com', 'user@gmail.com', 'PHP Configuration Success', '<p>Hi user (user@gmail.com),&nbsp;</p><p>Your email notification setting is configured successfully for MinStack</p>', 'email', '2025-10-02 02:11:52', '2025-10-02 02:11:52'),
(119, 0, 'custom', 'notify@example.com', '436641234567', ' ', 'Hi   (436641234567), \r\nYour sms notification setting is configured successfully for MinStack', 'sms', '2025-10-02 02:17:51', '2025-10-02 02:17:51'),
(120, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi John Doe (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-10-22 12:04:41 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Handheld Browser</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Android&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">595157</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-10-22 06:04:41', '2025-10-22 06:04:41');

-- --------------------------------------------------------

--
-- Table structure for table `notification_templates`
--

CREATE TABLE `notification_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subj` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_body` text COLLATE utf8mb4_general_ci,
  `sms_body` text COLLATE utf8mb4_general_ci,
  `shortcodes` text COLLATE utf8mb4_general_ci,
  `email_status` tinyint(1) NOT NULL DEFAULT '1',
  `sms_status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_templates`
--

INSERT INTO `notification_templates` (`id`, `act`, `name`, `subj`, `email_body`, `sms_body`, `shortcodes`, `email_status`, `sms_status`, `created_at`, `updated_at`) VALUES
(7, 'PASS_RESET_CODE', 'Password - Reset - Code', 'Password Reset', '<div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">{{time}} .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">{{ip}}</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">{{browser}}</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{operating_system}}&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">{{code}}</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div>', 'Your account recovery code is: {{code}}', '{\"code\":\"Verification code for password reset\",\"ip\":\"IP address of the user\",\"browser\":\"Browser of the user\",\"operating_system\":\"Operating system of the user\",\"time\":\"Time of the request\"}', 1, 0, '2021-11-03 12:00:00', '2022-03-20 20:47:05'),
(8, 'PASS_RESET_DONE', 'Password - Reset - Confirmation', 'You have reset your password', '<p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">{{ip}}</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">{{browser}}</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{operating_system}}&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{time}}</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p>', 'Your password has been changed successfully', '{\"ip\":\"IP address of the user\",\"browser\":\"Browser of the user\",\"operating_system\":\"Operating system of the user\",\"time\":\"Time of the request\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-05 03:46:35'),
(10, 'EVER_CODE', 'Verification - Email', 'Please verify your email address', '<br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;{{code}}</span></font></div></div>', '---', '{\"code\":\"Email verification code\"}', 1, 0, '2021-11-03 12:00:00', '2022-04-03 02:32:07'),
(11, 'SVER_CODE', 'Verification - SMS', 'Verify Your Mobile Number', '---', 'Your phone verification code is: {{code}}', '{\"code\":\"SMS Verification Code\"}', 0, 1, '2021-11-03 12:00:00', '2022-03-20 19:24:37'),
(15, 'DEFAULT', 'Default Template', '{{subject}}', '{{message}}', '{{message}}', '{\"subject\":\"Subject\",\"message\":\"Message\"}', 1, 1, '2019-09-14 13:14:22', '2021-11-04 09:38:55');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `slug` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `secs` text COLLATE utf8mb4_general_ci,
  `meta_title` varchar(60) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meta_description` varchar(160) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `secs`, `meta_title`, `meta_description`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'Home', '/', '[\"banner\",\"brand_strip\",\"service\",\"about\",\"how_it_works\",\"why_choose_us\",\"counter\",\"testimonial\",\"blog\",\"faq\",\"cta\"]', NULL, NULL, 1, '2020-07-11 06:23:58', '2026-08-29 01:05:06'),
(4, 'Blog', 'blog', '[]', 'Blog', NULL, 1, '2020-10-22 01:14:43', '2026-09-29 07:38:04'),
(5, 'Contact', 'contact', '[\"contact_faq\"]', NULL, NULL, 1, '2020-10-22 01:14:53', '2026-08-31 23:51:38'),
(22, 'Pickup Request', 'pickup', '[]', NULL, NULL, 1, '2026-08-30 03:44:22', '2026-08-30 03:44:22'),
(23, 'Get a Quote', 'quote', '[]', NULL, NULL, 1, '2026-08-30 03:44:23', '2026-08-30 03:44:23'),
(24, 'About', 'about', '[\"our_story\",\"mission_vision\",\"counter\",\"team\",\"cta\"]', NULL, NULL, 1, '2026-08-30 03:44:23', '2026-08-31 23:01:20'),
(25, 'Online Booking', 'book', '[]', NULL, NULL, 1, '2026-08-30 03:44:23', '2026-08-30 03:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` bigint NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`) VALUES
(3, 'user@site.com', '251321', '2025-07-02 06:14:08'),
(4, 'testuser@gmail.com', '595157', '2025-10-22 06:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint NOT NULL,
  `groupby` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => admin 2 => user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `groupby`, `name`, `slug`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard', 'Dashboard', 'dashboard', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(2, 'Role Management', 'Role', 'role', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(3, 'Staff Mangement', 'Staff Management', 'staff', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(4, 'User Management', 'User Management', 'user-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(5, 'Subscriber Management', 'Subscriber Management', 'subscriber-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(6, 'Deposit Management', 'Deposit Management', 'deposit-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(7, 'Withdraw Management', 'Withdraw Management', 'withdraw-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(8, 'Payment Method', 'Payment Method', 'payment-method', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(9, 'Withdraw Method', 'Withdraw Method', 'withdraw-method', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(10, 'Support Ticket', 'Support Ticket', 'support-ticket', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(11, 'Report Management', 'Reports', 'reports', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(12, 'Global Settings', 'Settings', 'settings', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(13, 'Page Management', 'Page Management', 'page-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(14, 'Section Management', 'Section Management', 'section-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(15, 'Language Management', 'Language Management', 'language-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(16, 'Plugin Management', 'Plugin Management', 'plugin-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(17, 'Kyc Management', 'Kyc', 'kyc', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(18, 'Topbar Notification', 'Admin Notification', 'admin-notification', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57'),
(19, 'Website Menu Management', 'Website Menu Management', 'website-menu-management', 1, '2025-07-24 04:46:57', '2025-07-24 04:46:57');

-- --------------------------------------------------------

--
-- Table structure for table `permission_roles`
--

CREATE TABLE `permission_roles` (
  `id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `permission_id` bigint NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1 => admin 2 => user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_general_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(29, 'App\\Models\\User', 22, 'MyApp', '5da1bfd64a5d95722d5c085185f0787323270c5cf12d09c5a69e4f950f4d8420', '[\"*\"]', NULL, NULL, '2021-05-19 05:47:02', '2021-05-19 05:47:02'),
(46, 'App\\Models\\User', 25, 'auth_token', 'bc7288b4e2082a0475639d6e2f29483a35abd11f55110df12244d9142f7ca54a', '[\"*\"]', NULL, NULL, '2021-06-10 05:35:17', '2021-06-10 05:35:17'),
(47, 'App\\Models\\User', 25, 'auth_token', '2bcdbee9ab110af212b02516a602ba52cf27a6aa844901acbb2fbfc09c95bb34', '[\"*\"]', NULL, NULL, '2021-06-10 06:31:50', '2021-06-10 06:31:50'),
(51, 'App\\Models\\User', 26, 'auth_token', 'c792344d1730dde4e418f6380309b24767062dc5e9c6757fce88675f7bbff9f3', '[\"*\"]', NULL, NULL, '2021-06-10 08:38:29', '2021-06-10 08:38:29'),
(53, 'App\\Models\\User', 24, 'auth_token', '36c0eb2f6065deb315bd996e158aed1d6c06f4a04879317bcf1961ea786a675c', '[\"*\"]', '2021-06-10 13:04:13', NULL, '2021-06-10 09:36:52', '2021-06-10 13:04:13'),
(54, 'App\\Models\\User', 24, 'auth_token', 'ddcfe3a5d501093c86a0a376a125099517199ea17ee9d4d78be12e476e413b40', '[\"*\"]', '2021-06-10 10:05:35', NULL, '2021-06-10 10:05:22', '2021-06-10 10:05:35'),
(55, 'App\\Models\\User', 24, 'auth_token', 'ecf248b74ee8bff942c22b299ccb3afe840a589b7dbd62b9897cbe46ea6c8941', '[\"*\"]', NULL, NULL, '2021-06-10 11:56:06', '2021-06-10 11:56:06'),
(58, 'App\\Models\\User', 8, 'auth_token', 'e572eaf82d8c9849394bb7790486730ab529e6ab53d9e4abc14dd69bd70bbd3f', '[\"*\"]', NULL, NULL, '2022-03-22 10:47:56', '2022-03-22 10:47:56'),
(59, 'App\\Models\\User', 8, 'auth_token', '21b0d071e22f45a7520c36b825b4f2582037004ee019e67707a4c6cabcbc9375', '[\"*\"]', '2022-04-05 05:13:26', NULL, '2022-03-22 10:48:33', '2022-04-05 05:13:26'),
(60, 'App\\Models\\User', 31, 'auth_token', '29647be4a8b5510c717c50b8279d168717ebcc25b3d0155fcc840cd315527112', '[\"*\"]', NULL, NULL, '2022-03-22 11:22:57', '2022-03-22 11:22:57'),
(61, 'App\\Models\\User', 8, 'auth_token', '9b103d59a6f148c7153e4c411fac11bf46e8ebeb886835c967a3f3896476da29', '[\"*\"]', '2022-04-16 06:29:21', NULL, '2022-03-29 08:05:49', '2022-04-16 06:29:21');

-- --------------------------------------------------------

--
-- Table structure for table `pickup_requests`
--

CREATE TABLE `pickup_requests` (
  `id` bigint UNSIGNED NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_time` datetime NOT NULL,
  `destination_country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pickup_requests`
--

INSERT INTO `pickup_requests` (`id`, `company_name`, `name`, `email`, `phone`, `pickup_time`, `destination_country`, `pickup_address`, `weight`, `item_type`, `message`, `status`, `created_at`, `updated_at`) VALUES
(4, 'techven', 'Md. Yasin Ali', 'yasinalibd02@gmail.com', '1308985262', '2026-09-10 19:16:00', 'Bangladesh', 'Dhaka, Mirpur', '2kg', 'parcel', NULL, 0, '2026-09-26 07:10:51', '2026-09-26 07:10:51'),
(5, 'SOS Creations Ltd.', 'Md. Aminul Haque', 'sucoorbrand@gmail.com', '1713607127', '2026-09-27 15:00:00', 'China', 'House# 832, Road# 12, Avenue# 4, Mirpur DOHS', '5', 'RMG', 'Pls Collect Urgently...', 2, '2026-09-27 07:33:04', '2026-09-27 07:35:57');

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE `plugins` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `script` text COLLATE utf8mb4_general_ci,
  `shortcode` text COLLATE utf8mb4_general_ci COMMENT 'object',
  `support` text COLLATE utf8mb4_general_ci COMMENT 'help section',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>enable, 2=>disable',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plugins`
--

INSERT INTO `plugins` (`id`, `act`, `name`, `description`, `image`, `script`, `shortcode`, `support`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'tawk-chat', 'Live Chat(Tawk.to)', 'Key location is shown bellow', 'chat-png.png', '<script>\n                        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();\n                        (function(){\n                        var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];\n                        s1.async=true;\n                        s1.src=\"https://embed.tawk.to/{{app_key}}\";\n                        s1.charset=\"UTF-8\";\n                        s1.setAttribute(\"crossorigin\",\"*\");\n                        s0.parentNode.insertBefore(s1,s0);\n                        })();\n                    </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"dddddddddddd\"}}', 'twak.png', 0, NULL, '2019-10-18 23:16:05', '2025-08-24 00:56:53'),
(2, 'google-recaptcha2', 'Google Recaptcha 2', 'Key location is shown bellow', 'recaptcha2.png', '\n<script src=\"https://www.google.com/recaptcha/api.js\"></script>\n<div class=\"g-recaptcha\" data-sitekey=\"{{site_key}}\" data-callback=\"verifyCaptcha\"></div>\n<div id=\"g-recaptcha-error\"></div>', '{\"site_key\":{\"title\":\"Site Key\",\"value\":\"6LdPC88fAAAAADQlUf_DV6Hrvgm-pZuLJFSLDOWV\"},\"secret_key\":{\"title\":\"Secret Key\",\"value\":\"6LdPC88fAAAAAG5SVaRYDnV2NpCrptLg2XLYKRKB\"}}', 'recaptcha.png', 0, NULL, '2019-10-18 23:16:05', '2025-07-01 23:58:26'),
(3, 'google-analytics', 'Google Analytics', 'Key location is shown bellow', 'google_analytics.png', '<script async src=\"https://www.googletagmanager.com/gtag/js?id={{app_key}}\"></script>\r\n                <script>\r\n                  window.dataLayer = window.dataLayer || [];\r\n                  function gtag(){dataLayer.push(arguments);}\r\n                  gtag(\"js\", new Date());\r\n                \r\n                  gtag(\"config\", \"{{app_key}}\");\r\n                </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"G-JGB5GZ3G69\"}}', 'ganalytics.png', 0, '2025-07-20 19:47:55', '2025-07-20 13:47:55', '2025-08-12 05:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `quote_requests`
--

CREATE TABLE `quote_requests` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destination_country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collection_option` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint NOT NULL,
  `user_id` bigint NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => admin, 2 => user',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => enable, 0 => disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `user_id`, `name`, `type`, `status`, `created_at`, `updated_at`) VALUES
(2, 0, 'Contributor', 1, 1, '2025-07-05 05:21:11', '2025-07-24 05:08:37'),
(3, 0, 'Editor', 1, 1, '2025-07-05 05:22:34', '2025-07-24 05:08:13'),
(4, 0, 'Member', 1, 1, '2025-07-07 00:16:17', '2025-07-24 05:08:03'),
(8, 0, 'Moderator', 1, 0, '2025-07-07 01:49:59', '2025-08-23 01:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_attachments`
--

CREATE TABLE `support_attachments` (
  `id` bigint UNSIGNED NOT NULL,
  `support_message_id` int UNSIGNED DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_messages`
--

CREATE TABLE `support_messages` (
  `id` bigint UNSIGNED NOT NULL,
  `support_ticket_id` int UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` int UNSIGNED NOT NULL DEFAULT '0',
  `message` longtext COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `support_messages`
--

INSERT INTO `support_messages` (`id`, `support_ticket_id`, `admin_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 'Phone: 442218337\n\nHey team anexpressbd.com,\r\n\r\nI would like to discuss SEO!\r\n\r\nWe help businesses rank higher on Google while also increasing their presence on AI-powered search platforms like ChatGPT, Gemini, Claude, and Perplexity.\r\n\r\nOur SEO + AEO + GEO strategies help brands get discovered wherever customers search for answers.\r\n\r\nMay I send you a quote & price list?\r\n\r\nCheers,\r\nRosabel Edney | Founder & Project Head', '2026-09-18 05:16:27', '2026-09-18 05:16:27'),
(2, 2, 0, 'Phone: 93135213\n\nHi,\r\n\r\nI was looking over your website and noticed a few specific areas where optimization could boost your Google rankings and attract higher-quality leads.\r\n\r\nI have put together a brief SEO strategy and pricing proposal designed to help scale your organic growth.\r\n\r\nWould you be open to reviewing it?\r\n\r\nBest regards,\r\n\r\nJack', '2026-09-18 10:05:45', '2026-09-18 10:05:45'),
(3, 3, 0, 'Hi,\r\n\r\nYour website anexpressbd.com really stood out to me. I can see some solid opportunities to build on what you already have and take things to the next level, both in terms of ROI and overall reach.\r\n\r\nWith over 26 years of experience, V Group specializes in scaling websites the right way, ensuring they\'re accessible and compliant so they reach the widest possible audience.\r\n\r\nWould you have some time this week to connect and explore this further?\r\n\r\nBest Regards,\r\nManshi Sharma', '2026-09-18 10:06:47', '2026-09-18 10:06:47'),
(4, 4, 0, 'Phone: 91504757\n\nHey\r\n\r\nInclude anexpressbd.com in Google\'s Search Index to show up in web search results!\r\n\r\nList anexpressbd.com now:\r\n\r\ndomainsubmit.site', '2026-09-22 19:43:50', '2026-09-22 19:43:50'),
(5, 5, 0, 'Phone: 2102102101\n\nHi anexpressbd.com,\r\n\r\nDo you have any plans to update, revamp, or improve your website soon?\r\n\r\nA modern, well-designed website can make a big difference in how your business is presented online and how effectively it converts visitors into customers.\r\n\r\nOur team provides a range of digital services, including:\r\n\r\nWebsite Design & Development\r\nWebsite Redesign & Revamp\r\nMobile App Development\r\nE-Commerce Website Development\r\nSEO & Search Engine Optimization\r\nDigital Marketing\r\nBrand Promotion & Online Branding\r\nSocial Media Marketing\r\nWebsite Speed & Performance Optimization\r\nUI/UX Design\r\nWe focus on clean and professional design, mobile responsiveness, fast loading speed, SEO-friendly development, and a better user experience to help businesses strengthen their online presence and generate more leads.\r\n\r\nIf you’re interested, I can share some of our recent work along with a few pricing options based on your requirements.\r\n\r\nWould you like me to send you some examples and a brief proposal?\r\n\r\nBest regards,\r\nEdward', '2026-09-28 22:07:16', '2026-09-28 22:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int DEFAULT '0',
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ticket` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: Open, 1: Answered, 2: Replied, 3: Closed',
  `priority` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = Low, 2 = medium, 3 = heigh',
  `last_reply` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `support_tickets`
--

INSERT INTO `support_tickets` (`id`, `user_id`, `name`, `email`, `ticket`, `subject`, `status`, `priority`, `last_reply`, `created_at`, `updated_at`) VALUES
(1, 0, 'Rosabel Edney', 'mapmybiz.mkt@gmail.com', '27085295', 'Quick SEO Idea for Your New Website', 0, 2, '2026-09-18 05:16:27', '2026-09-18 05:16:27', '2026-09-18 05:16:27'),
(2, 0, 'Jack', 'jack287989@gmail.com', '42710999', 'Question about your Google visibility', 0, 2, '2026-09-18 10:05:45', '2026-09-18 10:05:45', '2026-09-18 10:05:45'),
(3, 0, 'Sharma', 'manshis@vgroupinc.com', '76423193', 'A quick note about your website recommndations', 0, 2, '2026-09-18 10:06:47', '2026-09-18 10:06:47', '2026-09-18 10:06:47'),
(4, 0, 'Ethel Lapp', 'domains@search-anexpressbd.com', '20816988', 'Results for anexpressbd.com', 0, 2, '2026-09-22 19:43:50', '2026-09-22 19:43:50', '2026-09-22 19:43:50'),
(5, 0, 'Edward Mkt', 'santiagoedward59@gmail.com', '01624244', 'Web, App & SEO Services for anexpressbd.com', 0, 2, '2026-09-28 22:07:16', '2026-09-28 22:07:16', '2026-09-28 22:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `post_balance` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `trx_type` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `trx` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `details` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remark` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint NOT NULL DEFAULT '0',
  `role_id` bigint NOT NULL DEFAULT '0',
  `firstname` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `country_code` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mobile` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ref_by` int UNSIGNED NOT NULL DEFAULT '0',
  `balance` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_general_ci COMMENT 'contains full address',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0: banned, 1: active',
  `kyc_data` text COLLATE utf8mb4_general_ci,
  `kv` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: KYC Unverified, 2: KYC pending, 1: KYC verified',
  `ev` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: email unverified, 1: email verified',
  `sv` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: mobile unverified, 1: mobile verified',
  `reg_step` tinyint(1) NOT NULL DEFAULT '0',
  `ver_code` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'stores verification code',
  `ver_code_send_at` datetime DEFAULT NULL COMMENT 'verification send time',
  `ts` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: 2fa off, 1: 2fa on',
  `tv` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0: 2fa unverified, 1: 2fa verified',
  `tsc` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ban_reason` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `parent_id`, `role_id`, `firstname`, `lastname`, `username`, `email`, `country_code`, `mobile`, `ref_by`, `balance`, `password`, `image`, `address`, `status`, `kyc_data`, `kv`, `ev`, `sv`, `reg_step`, `ver_code`, `ver_code_send_at`, `ts`, `tv`, `tsc`, `ban_reason`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 0, 'John', 'Doe', 'testuser', 'testuser@gmail.com', 'HK', '85521471117', 0, 1090.00000000, '$2y$12$4HvhGzJkvKMlDY7/HP4ZluGCOCxsWbKdb1CWGuLO1xkf4CGWD230C', NULL, '{\"country\":\"Afghanistan\",\"address\":\"Test\",\"state\":\"Test\",\"zip\":\"Test\",\"city\":\"Test\"}', 1, NULL, 1, 1, 1, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, '2025-07-08 00:27:50', '2025-09-21 06:54:54'),
(2, 0, 0, 'Emma', 'Smith', 'emmasmith', 'emma.smith@example.com', 'GB', '447700900900', 0, 0.00000000, '$2y$10$kvu.xRlHv32YheJWV3NWneQR0vPIA5Eev01jUjQeieHQDJSE1XXs.', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Antigua and Barbuda\",\"city\":\"\"}', 1, NULL, 0, 1, 1, 0, '217802', '2020-11-19 10:18:39', 0, 1, NULL, NULL, NULL, '2020-11-19 04:18:38', '2025-09-21 06:54:54'),
(3, 0, 0, 'Liam', 'Brown', 'liambrown', 'liam.brown@example.com', 'CA', '14165551122', 0, 0.00000000, '$2y$10$UD7lj91bK2SK0CEqtIi/s.XZKh8Wm.ajz1DimEuoDBLiNAE29zY7a', NULL, '{\"address\":\"Address\",\"city\":\"FFF\",\"state\":\"7878\",\"zip\":\"5874\",\"country\":\"Algeria\"}', 1, NULL, 0, 1, 1, 0, '112922', '2020-11-23 12:45:44', 0, 1, NULL, NULL, NULL, '2020-11-23 06:45:43', '2025-09-21 06:54:54'),
(4, 0, 0, 'Sophia', 'Williams', 'sophiaw', 'sophia.w@example.com', 'AU', '61412345678', 0, 1180.00000000, '$2y$10$0TizysQNL9Yw6DYOji5Eh.mrstho4NhuVam7ssaCYS0Y9JegnopZG', '1615803362_testuser123.jpg', '{\"address\":\"Dhaka\",\"city\":\"Dhaka\",\"state\":\"Dhaka\",\"zip\":\"1230\",\"country\":\"Lithuania\"}', 1, NULL, 0, 1, 1, 0, '950194', '2021-03-15 09:35:45', 0, 1, NULL, NULL, NULL, '2021-03-15 03:35:45', '2025-09-21 06:54:54'),
(5, 0, 0, 'Noah', 'Johnson', 'noahj', 'noah.j@example.com', 'NZ', '64211234567', 0, 0.00000000, '$2y$10$bV6Mi/8uv/MirSHWtn8qz.txLfzvSaovndD.GPCoCaHD8UK/bdJOi', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Afghanistan\",\"city\":\"\"}', 1, NULL, 0, 0, 1, 0, '439780', '2021-04-17 07:17:26', 0, 1, NULL, NULL, NULL, '2021-04-17 01:17:26', '2025-09-21 06:54:54'),
(6, 0, 0, 'Isabella', 'Garcia', 'isagarcia', 'isabella.g@example.com', 'ES', '34612345678', 0, 0.00000000, '$2y$10$jbMEuGQ/U.gTPihO4jfBD.wnnWgZNyhj3n2VUkp0V2LOaGau6HbF6', NULL, '{\"address\":null,\"city\":null,\"state\":null,\"zip\":null,\"country\":\"Bangladesh\"}', 1, NULL, 0, 0, 1, 0, '404482', '2021-04-28 06:41:42', 0, 1, NULL, NULL, NULL, '2021-04-28 00:41:42', '2025-09-21 06:54:54'),
(7, 0, 0, 'James', 'Martinez', 'jmartinez', 'james.m@example.com', 'MX', '525512345678', 0, 0.00000000, '$2y$10$.tD1XpK.E4ubM4Pg3yEuYO3tzMasHqd2pzsRjm8nGYKhIwxTmNI/2', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Afghanistan\",\"city\":\"\"}', 1, NULL, 0, 1, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2021-05-10 06:24:07', '2025-09-21 06:54:54'),
(8, 0, 0, 'Mia', 'Rodriguez', 'miarod', 'mia.r@example.com', 'AR', '5491122334455', 8, 10010.00000000, '$2y$10$0BuEBEfe82oTukY9BFrODeFP9d4sS7KJdoHBPk1oziRkKAC/D8VOi', NULL, '{\"country\":\"Andorra\",\"address\":\"Lakewood, CA 90805, Locker, TX 76801\",\"state\":\"California\",\"zip\":\"90805\",\"city\":\"Lakewood\"}', 1, NULL, 0, 1, 1, 1, NULL, NULL, 1, 1, 'FSLM3BZVLNPY7JYI', NULL, NULL, '2021-05-10 06:27:04', '2025-09-21 06:54:54'),
(9, 0, 0, 'William', 'Lee', 'willlee', 'rajib@example.com', 'SG', '6581234567', 0, 0.00000000, '$2y$10$OhSvy7ncR6dBuhTnUvmiXuJRjpLfjWtZdE2uYKx/P46lJoZ00omfC', NULL, '{\"country\":\"Australia\",\"address\":\"472 Clark Street, Bay Shore, New York\",\"state\":\"London\",\"zip\":\"3444\",\"city\":\"New York\"}', 1, '[{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Alex Smith\"},{\"name\":\"NID Number\",\"type\":\"text\",\"value\":\"45544545\"},{\"name\":\"Gender\",\"type\":\"select\",\"value\":\"Male\"},{\"name\":\"You Hobby\",\"type\":\"checkbox\",\"value\":[\"Programming\",\"Gardening\",\"Traveling\",\"Others\"]},{\"name\":\"NID Photo\",\"type\":\"file\",\"value\":\"2025\\/06\\/25\\/685bd3e9d5e1c1750848489.jpg\"}]', 2, 1, 1, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, '2021-05-19 05:47:02', '2025-09-21 06:54:54'),
(10, 0, 0, 'Charlotte', 'Kim', 'charlottek', 'charlotte.k@example.com', 'KR', '821023456789', 0, 0.00000000, '$2y$10$19byGz10jEXEQDxsoLTrMug4qYnuzT9O3S4.o0w8YN72mruuGh.8m', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Anguilla\",\"city\":\"\"}', 1, NULL, 0, 0, 1, 0, '467842', '2021-06-09 12:15:34', 0, 1, NULL, NULL, NULL, '2021-06-09 06:15:33', '2025-09-21 06:54:54'),
(11, 0, 0, 'Benjamin', 'Nguyen', 'bennyng', 'benjamin.n@example.com', 'VN', '84912345678', 0, 0.00000000, '$2y$10$hv5l/n1.Y2WcQGPM13NR5uuditJgwr89jHnZabxyz738pf5MFxc5i', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Bangladesh\",\"city\":\"\"}', 1, NULL, 0, 1, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2021-06-10 05:31:54', '2025-09-21 06:54:54'),
(12, 0, 0, 'RH', 'Rajib', 'rhrajib', 'rajib@gmail.com', 'US', '12025550171', 0, 24707.55755565, '$2y$12$ywOznl0LNgbSzQSXt70.5uOgTjh7NOquUxkehK/76hTIOIpImbayy', NULL, '{\"address\":null,\"state\":null,\"zip\":null,\"country\":\"Bangladesh\",\"city\":null}', 1, NULL, 1, 1, 1, 1, '119199', '2022-04-03 10:49:17', 0, 1, NULL, NULL, 'g8KmRYrgEj9x3WkHGxcJwCj5NvQ2mBXofNZR43W0oOpY4hEU7CKRPXubHzH2', '2020-07-25 00:40:06', '2025-09-21 06:54:54'),
(13, 0, 0, 'Lucas', 'Tanaka', 'lucast', 'lucas.t@example.com', 'JP', '819012345678', 0, 0.00000000, '$2y$10$zP92objty3B6R/k9A4FIs.vT4SUXQGDgFIIwCK//3dpnp0s6Xr/aW', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Bangladesh\",\"city\":\"\"}', 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2021-06-10 08:38:28', '2025-09-21 06:54:54'),
(14, 0, 0, 'Harper', 'Singh', 'harpers', 'harper.s@example.com', 'IN', '919812345678', 0, 0.00000000, '$2y$10$bnERS5Za.TVGNxb89ttI2eIc10.kDEXK8hTkUS5Ob7sKpN7N8vRHa', NULL, '{\"address\":null,\"city\":null,\"state\":null,\"zip\":null,\"country\":\"Afghanistan\"}', 1, NULL, 0, 1, 1, 0, '994511', '2022-03-06 11:53:38', 1, 0, NULL, NULL, NULL, '2021-06-12 05:27:14', '2025-09-21 06:54:54'),
(15, 0, 0, 'Henry', 'Kowalski', 'henryk', 'henry.k@example.com', 'PL', '48512345678', 0, 0.00000000, '$2y$10$LYPdpUJDnCfG7MXUF0ydaOX5ESI6dLrjlrnh9QJ0YgaJdRSPMs9HS', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Algeria\",\"city\":\"\"}', 1, NULL, 0, 1, 1, 0, '210333', '2022-03-17 09:09:59', 0, 1, NULL, NULL, NULL, '2022-03-17 03:09:58', '2025-09-21 06:54:54'),
(16, 0, 0, 'Evelyn', 'Dubois', 'evedub', 'evelyn.d@example.com', 'FR', '33612345678', 0, 200.00000000, '$2y$10$5iSye35hvir6jdd1nMx5/elcysmkvfrTFCfK0MLV5nb9QsA2Q7ury', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Saint Kitts and Nevis\",\"city\":\"\"}', 1, NULL, 0, 1, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2022-03-21 02:41:54', '2025-09-21 06:54:54'),
(17, 0, 0, 'Alexander', 'Schmidt', 'alexsch', 'alex.s@example.com', 'DE', '4915123456789', 0, 0.00000000, '$2y$10$tw6Ppdztjt6WbFA61GYHAuvnUl4zI3j2jMcMGp8UVMzHF32ACWCjG', NULL, '{\"country\":\"Colombia\",\"address\":\"Vitae labore iure es\",\"state\":\"Sunt nisi et enim vo\",\"zip\":\"82702\",\"city\":\"In vel aspernatur si\"}', 1, NULL, 1, 1, 1, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, '2022-03-22 07:53:20', '2025-09-21 06:54:54'),
(18, 0, 0, 'Daniel', 'Silva', 'dansilva', 'daniel.s@example.com', 'BR', '5521912345678', 0, 0.00000000, '$2y$10$M.ZMRFlWUCWXh3cb2htccuNxAG48bU6Q9PAqeHgXG4esiS82rWvM2', NULL, '{\"address\":null,\"city\":\"Dhaka\",\"state\":null,\"zip\":null,\"country\":\"Armenia\"}', 1, NULL, 1, 0, 1, 0, '285472', '2022-09-29 17:45:24', 0, 1, NULL, NULL, NULL, '2022-03-22 11:22:57', '2025-09-21 06:54:54'),
(19, 0, 0, 'Ava', 'Johansson', 'avaj', 'ava.j@example.com', 'SE', '46701234567', 0, 0.00000000, '$2y$10$PGHz5AGcAXPf2rSS1hD.su7SHL2.0ZP18ICA43OUhbceHm/s/reTK', NULL, '{\"country\":\"Afghanistan\",\"address\":\"Lakewood, CA 90805, Locker, TX 76801\",\"state\":\"California\",\"zip\":\"90805\",\"city\":\"Lakewood\"}', 1, NULL, 1, 1, 1, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, '2023-03-22 04:09:55', '2025-09-21 06:54:54'),
(20, 0, 0, 'Matthew', 'OConnor', 'mattoc', 'matthew.o@example.com', 'IE', '353871234567', 0, 10.00000000, '$2y$12$hmLeB7KkiKy71/yXoZM5qOQFGiam2ZqjQrzbHRHbbpoz3Xn6K1wfS', NULL, '{\"address\":\"472 Clark Street, Bay Shore, New York\",\"city\":\"New York\",\"state\":\"test\",\"zip\":\"3444\",\"country\":\"Bangladesh\"}', 1, NULL, 1, 1, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2025-06-30 04:29:12', '2025-09-21 06:54:54'),
(21, 0, 0, 'Amelia', 'Chen', 'ameliach', 'amelia.c@example.com', 'CN', '8613123456789', 0, 0.00000000, '$2y$10$6VyFIftVzo9o4Mx.pHRCQOTUgOdWMMbLUHYhNfjRdVHHmTHrjHn9a', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Bangladesh\",\"city\":\"\"}', 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2021-06-10 05:35:17', '2025-09-21 06:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_logins`
--

CREATE TABLE `user_logins` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `user_ip` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country_code` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `longitude` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `latitude` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `browser` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `os` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_logins`
--

INSERT INTO `user_logins` (`id`, `user_id`, `user_ip`, `city`, `country`, `country_code`, `longitude`, `latitude`, `browser`, `os`, `created_at`, `updated_at`) VALUES
(1, 32, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2023-03-22 04:09:56', '2023-03-22 04:09:56'),
(2, 8, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-06-28 04:30:14', '2025-06-28 04:30:14'),
(3, 8, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-02 06:15:21', '2025-07-02 06:15:21'),
(4, 8, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-02 06:16:08', '2025-07-02 06:16:08'),
(5, 8, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-02 06:42:19', '2025-07-02 06:42:19'),
(6, 8, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-02 06:44:17', '2025-07-02 06:44:17'),
(7, 8, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-07-03 03:10:28', '2025-07-03 03:10:28'),
(8, 8, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-07-07 05:54:42', '2025-07-07 05:54:42'),
(9, 34, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-08 00:27:50', '2025-07-08 00:27:50'),
(10, 34, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-07-17 04:18:39', '2025-07-17 04:18:39');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` bigint UNSIGNED NOT NULL,
  `method_id` int UNSIGNED NOT NULL DEFAULT '0',
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `currency` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `trx` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `final_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `after_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `withdraw_information` text COLLATE utf8mb4_general_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=>success, 2=>pending, 3=>cancel,  ',
  `admin_feedback` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_methods`
--

CREATE TABLE `withdraw_methods` (
  `id` bigint UNSIGNED NOT NULL,
  `form_id` int UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `min_limit` decimal(28,8) DEFAULT '0.00000000',
  `max_limit` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `fixed_charge` decimal(28,8) DEFAULT '0.00000000',
  `rate` decimal(28,8) DEFAULT '0.00000000',
  `percent_charge` decimal(5,2) DEFAULT NULL,
  `currency` varchar(40) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdraw_methods`
--

INSERT INTO `withdraw_methods` (`id`, `form_id`, `name`, `min_limit`, `max_limit`, `fixed_charge`, `rate`, `percent_charge`, `currency`, `description`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 13, 'Tranfer from Bank', 1.00000000, 1000.00000000, 1.00000000, 1.00000000, 2.00, 'USD', '<p><i>This method is for internal bank-to-bank transfers. Provide your receiving bank details exactly as registered. Transfer will typically reflect within 2–5 business days depending on banks involved.</i></p>', '68ad62763fa621756193398.png', 1, '2022-03-30 09:09:11', '2025-09-21 07:25:23'),
(2, 14, 'Mobile Banking', 1.00000000, 1000.00000000, 0.00000000, 1.00000000, 0.01, 'USD', '<p><i>Provide the correct mobile banking number and account name. Make sure your mobile banking wallet is active and able to receive funds. Processing time is usually instant to 24 hours after approval.</i><br>&nbsp;</p>', '68ad626943d931756193385.png', 1, '2022-03-30 09:10:12', '2025-09-21 07:25:04'),
(3, 24, 'Bank Transfer', 1.00000000, 1000000000.00000000, 1.00000000, 1.00000000, 0.25, '$', '<p><i>Please ensure the bank account details are correct before submitting your request. Funds will be transferred within 1–3 business days after approval. Any incorrect information may result in delays or failed transfers.</i></p>', '68ad6251354db1756193361.png', 1, '2025-06-29 04:40:12', '2025-10-02 05:23:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`username`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_requests`
--
ALTER TABLE `booking_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frontends`
--
ALTER TABLE `frontends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gateways`
--
ALTER TABLE `gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gateway_currencies`
--
ALTER TABLE `gateway_currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_slug_unique` (`code`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_menu_items`
--
ALTER TABLE `menu_menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_logs`
--
ALTER TABLE `notification_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_templates`
--
ALTER TABLE `notification_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `pickup_requests`
--
ALTER TABLE `pickup_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plugins`
--
ALTER TABLE `plugins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quote_requests`
--
ALTER TABLE `quote_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_attachments`
--
ALTER TABLE `support_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_messages`
--
ALTER TABLE `support_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- Indexes for table `user_logins`
--
ALTER TABLE `user_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `booking_requests`
--
ALTER TABLE `booking_requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `frontends`
--
ALTER TABLE `frontends`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;

--
-- AUTO_INCREMENT for table `gateways`
--
ALTER TABLE `gateways`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `gateway_currencies`
--
ALTER TABLE `gateway_currencies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `menu_menu_items`
--
ALTER TABLE `menu_menu_items`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `notification_logs`
--
ALTER TABLE `notification_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `notification_templates`
--
ALTER TABLE `notification_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `permission_roles`
--
ALTER TABLE `permission_roles`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `pickup_requests`
--
ALTER TABLE `pickup_requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `plugins`
--
ALTER TABLE `plugins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quote_requests`
--
ALTER TABLE `quote_requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_attachments`
--
ALTER TABLE `support_attachments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_messages`
--
ALTER TABLE `support_messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user_logins`
--
ALTER TABLE `user_logins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
